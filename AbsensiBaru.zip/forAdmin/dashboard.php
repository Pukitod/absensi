<?php
session_start();

// Jika belum login, simpan halaman saat ini ke session dan arahkan ke login
if (!isset($_SESSION['login_user'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI']; // Simpan halaman yang ingin diakses
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");


// Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Placeholder queries - replace with actual queries
// Count total students
$sql_total_siswa = "SELECT COUNT(*) as total FROM users";
$result_total = $conn->query($sql_total_siswa);
$total_siswa = $result_total->fetch_assoc()['total'] ?? 0;

// Count departments/majors
$sql_jurusan = "SELECT COUNT(DISTINCT departemen) as total FROM users";
$result_jurusan = $conn->query($sql_jurusan);
$total_jurusan = $result_jurusan->fetch_assoc()['total'] ?? 0;

// Get recent students (last 5 added)
$sql_recent = "SELECT user_id, nama, jabatan, departemen, foto FROM users ORDER BY user_id DESC LIMIT 5";
$result_recent = $conn->query($sql_recent);


$tanggal_hari_ini = date('Y-m-d');
// Query untuk mendapatkan statistik kehadiran
$sql_total_siswa = "SELECT COUNT(*) as total FROM users";
$result_total = $conn->query($sql_total_siswa);
$total_siswa = ($result_total->num_rows > 0) ? $result_total->fetch_assoc()['total'] : 0;

$sql_hadir_hari_ini = "SELECT COUNT(DISTINCT user_id) as total FROM absensi WHERE tanggal = '$tanggal_hari_ini' AND status IN ('Hadir', 'Terlambat')";
$result_hadir = $conn->query($sql_hadir_hari_ini);
$total_hadir = ($result_hadir->num_rows > 0) ? $result_hadir->fetch_assoc()['total'] : 0;


// Hitung jumlah siswa yang tidak hadir (Izin, Sakit, Alpa, atau tidak absen)
$sql_tidak_hadir = "
    SELECT COUNT(*) as total FROM users 
    WHERE user_id NOT IN (
        SELECT DISTINCT user_id FROM absensi WHERE tanggal = '$tanggal_hari_ini'
    ) 
    OR user_id IN (
        SELECT DISTINCT user_id FROM absensi WHERE tanggal = '$tanggal_hari_ini' AND status IN ('Izin', 'Sakit', 'Alpa')
    )
";
$result_tidak_hadir = $conn->query($sql_tidak_hadir);
$total_tidak_hadir = ($result_tidak_hadir->num_rows > 0) ? $result_tidak_hadir->fetch_assoc()['total'] : 0;

$persentase_hadir = ($total_siswa > 0) ? round(($total_hadir / $total_siswa) * 100, 2) : 0;

// Get data for attendance by status
$sql_status = "SELECT status, COUNT(*) as total FROM absensi WHERE tanggal = '$tanggal_hari_ini' GROUP BY status";
$result_status = $conn->query($sql_status);
$status_data = [];
while ($row = $result_status->fetch_assoc()) {
    $status_data[$row['status']] = $row['total'];
}


// Get data for recent absences
$sql_recent_absences = "SELECT a.tanggal, a.waktu, a.status, u.nama, u.jabatan, u.departemen, u.foto 
                        FROM absensi a 
                        JOIN users u ON a.user_id = u.user_id 
                        WHERE a.tanggal = '$tanggal_hari_ini'
                        ORDER BY a.waktu DESC 
                        LIMIT 5";
$result_recent_absences = $conn->query($sql_recent_absences);


?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistem Manajemen Siswa</title>
    <link rel="stylesheet" href="assets/css/style.css">
        </head>
<body class="bg-light">

<!-- Header Menu -->
<header class="header">
    <div class="container nav-container">
        <div class="logo">
            <a href="dashboard.php" class="logo-link">Sistem Manajemen Siswa</a>
        </div>
        <ul class="nav-menu">
            <li><a href="dashboard.php" class="active">Dashboard</a></li>
            <li><a href="daftar_siswa.php">Daftar Siswa</a></li>
            <li><a href="data_absensi.php">Data Absensi</a></li>
            <li><a href="data_izin.php">Data Izin</a></li>
            <li><a href="tambah_siswa.php">Tambah Siswa</a></li>
        </ul>
        <div class="hamburger" id="hamburger-menu">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</header>

<!-- Mobile Navigation Menu -->
<div class="mobile-nav-overlay" id="mobile-overlay"></div>
<nav class="mobile-nav" id="mobile-nav">
    <button class="mobile-nav-close" id="mobile-nav-close">✕</button>
    
    <div class="mobile-nav-header">
        <div class="mobile-user-profile">
            <div class="mobile-user-avatar">
                <?php echo substr($_SESSION['login_user'] ?? 'A', 0, 1); ?>
            </div>
            <div class="mobile-user-info">
                <div class="mobile-user-name"><?php echo $_SESSION['login_user'] ?? 'Admin'; ?></div>
                <div class="mobile-user-role">Administrator</div>
            </div>
        </div>
    </div>
    
    <ul class="mobile-menu">
        <li>
            <a href="dashboard.php" class="active">
                <span class="mobile-menu-icon">📊</span>
                Dashboard
            </a>
        </li>
        <li>
            <a href="daftar_siswa.php">
                <span class="mobile-menu-icon">👥</span>
                Daftar Siswa
            </a>
        </li>
        <li>
            <a href="data_absensi.php">
                <span class="mobile-menu-icon">📋</span>
                Data Absensi
            </a>
        </li>
        <li>
            <a href="data_izin.php">
                <span class="mobile-menu-icon">🗓️</span>
                Data Izin
            </a>
        </li>
        <li>
            <a href="tambah_siswa.php">
                <span class="mobile-menu-icon">➕</span>
                Tambah Siswa
            </a>
        </li>
        <li>
            <a href="pengaturan.php">
                <span class="mobile-menu-icon">⚙️</span>
                Pengaturan
            </a>
        </li>
    </ul>
    
    <div class="mobile-nav-footer">
        <a href="logout.php" class="mobile-logout-btn">
            <span class="mobile-logout-icon">🚪</span>
            Logout
        </a>
    </div>
</nav>

<div class="container content">
    <!-- Welcome Section -->
    <section class="welcome-section">
        <h1>Selamat Datang, <?php echo $_SESSION['login_user'] ?? 'Admin'; ?>!</h1>
        <p>Pantau aktivitas siswa dan kelola data dengan mudah melalui dashboard ini.</p>
        <div>
        <?php
$tanggal_tampil = date('d') . ' ' . [
    'January' => 'Januari',
    'February' => 'Februari',
    'March' => 'Maret',
    'April' => 'April',
    'May' => 'Mei',
    'June' => 'Juni',
    'July' => 'Juli',
    'August' => 'Agustus',
    'September' => 'September',
    'October' => 'Oktober',
    'November' => 'November',
    'December' => 'Desember'
][date('F')] . ' ' . date('Y');

$hari_tampil = [
    'Sunday' => 'Minggu',
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu'
][date('l')];
?>
<div class="date-display-dash"><?php echo $hari_tampil . ', ' . $tanggal_tampil; ?></div>

    </section>
    
    <!-- Statistics Cards -->
    <div class="stats-container">
        <div class="stat-card card-blue">
            <div class="stat-icon">👥</div>
            <div class="stat-number"><?php echo $total_siswa; ?></div>
            <div class="stat-label">Total Siswa</div>
        </div>

        <div class="stat-card card-green">
            <div class="stat-icon">✅</div>
            <div class="stat-number"><?php echo $total_hadir; ?></div>
            <div class="stat-label">Hadir Hari Ini</div>
        </div>

        <div class="stat-card card-red">
            <div class="stat-icon">🚫</div>
            <div class="stat-number"><?php echo $total_tidak_hadir; ?></div>
            <div class="stat-label">Izin / Sakit / Alpa</div>
        </div>

        <div class="stat-card card-purple">
            <div class="stat-icon">📊</div>
            <div class="stat-number"><?php echo $persentase_hadir; ?>%</div>
            <div class="stat-label">Persentase Kehadiran</div>
        </div>
    </div>
    
    
    <!-- Dashboard Grid -->
    <div class="dashboard-grid">
        <!-- Recent Students -->
        <div class="recent-students">
            <h3 class="section-title"><i>👥</i> Siswa Terbaru</h3>
            
            <ul class="student-list">
                <?php
                if ($result_recent && $result_recent->num_rows > 0) {
                    while ($row = $result_recent->fetch_assoc()) {
                        $foto = !empty($row['foto']) ? $row['foto'] : '../default.jpg';
                        echo '<li class="student-item">
                                <img src="../uploads/' . $foto . '" alt="Foto Siswa" class="student-photo">
                                <div class="student-info" style="display:block;">
                                    <div class="student-name">' . $row['nama'] . '</div>
                                    <div class="student-class">' . $row['jabatan'] . '</div>
                                </div>
                                <span class="student-major">' . $row['departemen'] . '</span>
                            </li>';
                    }
                } else {
                    echo '<li>Tidak ada data siswa terbaru.</li>';
                }
                ?>
            </ul>
            
            <a href="daftar_siswa.php" class="view-all">Lihat Semua Siswa →</a>
        </div>
        
        <!-- Quick Actions -->
        <div class="quick-actions">
            <h3 class="section-title"><i>⚡</i> Aksi Cepat</h3>
            
            <div class="action-buttons">
                <a href="tambah_siswa.php" class="action-btn">
                    <span class="icon">➕</span>
                    Tambah Siswa
                </a>
                
                <a href="daftar_siswa.php" class="action-btn">
                    <span class="icon">📝</span>
                    Daftar Siswa
                </a>
                
                <a href="data_absensi.php" class="action-btn">
                    <span class="icon">📊</span>
                    Data Absensi
                </a>
                
                <a href="data_izin.php" class="action-btn">
                    <span class="icon">🕙</span>
                    Data Izin
                </a>
                <a href="logout.php" class="action-btn">
                    <span class="icon">🚪</span>
                    Logout
                </a>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div class="recent-activity">
        <h3 class="section-title"><i>🔔</i> Aktivitas Absensi Terbaru</h3>
        
        <ul class="activity-list">
            <?php
            if ($result_recent_absences && $result_recent_absences->num_rows > 0) {
                while ($row = $result_recent_absences->fetch_assoc()) {
                    $foto = !empty($row['foto']) ? $row['foto'] : 'default.jpg';
                    $status_class = strtolower($row['status']);
                    $status_icon = '✅';
                    
                    if ($row['status'] == 'Terlambat') {
                        $status_icon = '⏰';
                    } elseif ($row['status'] == 'Izin') {
                        $status_icon = '📝';
                    } elseif ($row['status'] == 'Alpa') {
                        $status_icon = '❌';
                    }
                    
                    echo '<li class="activity-item">
                            <div class="activity-icon ' . $status_class . '">' . $status_icon . '</div>
                            <div class="activity-content">
                                <div class="activity-title">' . $row['nama'] . ' - ' . $row['status'] . '</div>
                                <div class="activity-subtitle">' . $row['jabatan'] . ' ' . $row['departemen'] . '</div>
                            </div>
                            <div class="activity-time">' . $row['waktu'] . '</div>
                          </li>';
                }
            } else {
                echo '<li class="activity-item">
                        <div class="activity-icon">📌</div>
                        <div class="activity-content">
                            <div class="activity-title">Belum ada aktivitas absensi hari ini</div>
                            <div class="activity-subtitle">Aktivitas akan muncul saat siswa melakukan absensi</div>
                        </div>
                      </li>';
            }
            ?>
        </ul>
        
        <div class="attendance-progress">
            <div class="progress-bar" style="width: <?php echo $persentase_hadir; ?>%;"></div>
        </div>
        <div class="progress-label">
            <span>Kehadiran Hari Ini</span>
            <span><?php echo $persentase_hadir; ?>%</span>
        </div>
        
        <a href="data_absensi.php" class="view-all">Lihat Semua Data Absensi →</a>
    </div>
</div>

<script>
// Hamburger menu functionality
const hamburger = document.getElementById('hamburger-menu');
const mobileNav = document.getElementById('mobile-nav');
const mobileOverlay = document.getElementById('mobile-overlay');
const mobileMenuLinks = document.querySelectorAll('.mobile-menu a');
const mobileNavClose = document.getElementById('mobile-nav-close');

function toggleMobileMenu() {
    hamburger.classList.toggle('active');
    mobileNav.classList.toggle('active');
    mobileOverlay.classList.toggle('active');
    document.body.style.overflow = mobileNav.classList.contains('active') ? 'hidden' : '';
}

hamburger.addEventListener('click', toggleMobileMenu);
mobileOverlay.addEventListener('click', toggleMobileMenu);
mobileNavClose.addEventListener('click', toggleMobileMenu);

// Close mobile menu when a link is clicked
mobileMenuLinks.forEach(link => {
    link.addEventListener('click', toggleMobileMenu);
});

</script>

</body>
</html>

<?php $conn->close(); ?>
