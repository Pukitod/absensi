<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['login_user'])) {
    // Jika belum login, redirect ke login.php
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Hapus semua data absensi setiap hari
$sql_hapus = "DELETE FROM absensi";
if ($conn->query($sql_hapus) === TRUE) {
    echo "Data absensi berhasil direset!";
} else {
    echo "Gagal mereset data: " . $conn->error;
}

$conn->close();
?>
