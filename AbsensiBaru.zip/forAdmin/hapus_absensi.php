<?php
session_start();

// Pastikan user sudah login dan memiliki akses
if (!isset($_SESSION['login_user'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tangkap ID absensi dari parameter URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $absensi_id = $_GET['id'];
    
    // Gunakan prepared statement untuk mencegah SQL injection
    $stmt = $conn->prepare("DELETE FROM absensi WHERE id = ?");
    $stmt->bind_param("i", $absensi_id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Data absensi berhasil dihapus";
    } else {
        $_SESSION['error'] = "Gagal menghapus data: " . $stmt->error;
    }
    
    $stmt->close();
} else {
    $_SESSION['error'] = "ID tidak valid";
}

$conn->close();
header("Location: data_absensi.php");
exit();
?>