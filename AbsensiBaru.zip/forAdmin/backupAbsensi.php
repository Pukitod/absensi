<?php
$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$bulan = date('m');
$tahun = date('Y');
$backup_table = "absensi_backup_{$tahun}_{$bulan}";

// Buat tabel baru
$sql_create = "CREATE TABLE IF NOT EXISTS $backup_table LIKE absensi";
if ($conn->query($sql_create) === TRUE) {
    $sql_insert = "INSERT INTO $backup_table SELECT * FROM absensi WHERE MONTH(tanggal) = '$bulan' AND YEAR(tanggal) = '$tahun'";
    if ($conn->query($sql_insert) === TRUE) {
        echo "Backup berhasil ke tabel $backup_table";
    } else {
        echo "Gagal menyimpan data ke tabel backup: " . $conn->error;
    }
} else {
    echo "Gagal membuat tabel backup: " . $conn->error;
}

$conn->close();
?>
