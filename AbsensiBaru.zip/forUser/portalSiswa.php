<?php
session_start();

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "absensi2");
date_default_timezone_set('Asia/Singapore');


// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Dummy user ID untuk testing
$user_id = "U001"; // Ganti dengan user ID yang valid di database Anda

// Ambil data user yang sedang login
$sql = "SELECT * FROM users WHERE user_id = '$user_id'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// Jika user tidak ditemukan, beri pesan error
if (!$user) {
    die("User tidak ditemukan. Pastikan user ID valid di database.");
}

// Ambil data absensi terbaru
$sql_absensi = "SELECT * FROM absensi WHERE user_id = '$user_id' ORDER BY tanggal DESC LIMIT 5";
$result_absensi = $conn->query($sql_absensi);

// Ambil data pengajuan cuti
$sql_cuti = "SELECT * FROM pengajuan_cuti WHERE user_id = '$user_id' ORDER BY created_at DESC LIMIT 3";
$result_cuti = $conn->query($sql_cuti);

// Hitung statistik
$sql_hadir = "SELECT COUNT(*) as total FROM absensi WHERE user_id = '$user_id' AND status = 'Hadir'";
$result_hadir = $conn->query($sql_hadir);
$total_hadir = $result_hadir->fetch_assoc()['total'];

$sql_izin = "SELECT COUNT(*) as total FROM absensi WHERE user_id = '$user_id' AND status = 'Izin'";
$result_izin = $conn->query($sql_izin);
$total_izin = $result_izin->fetch_assoc()['total'];

$sql_terlambat = "SELECT COUNT(*) as total FROM absensi WHERE user_id = '$user_id' AND status = 'Terlambat'";
$result_terlambat = $conn->query($sql_terlambat);
$total_terlambat = $result_terlambat->fetch_assoc()['total'];

// Tanggal dan waktu saat ini
$current_date = date("Y-m-d");
$current_time = date("H:i:s");

// Cek apakah sudah absen hari ini
$sql_check_absen = "SELECT * FROM absensi WHERE user_id = '$user_id' AND tanggal = '$current_date'";
$result_check = $conn->query($sql_check_absen);
$sudah_absen = $result_check->num_rows > 0;

// Proses absensi jika tombol absen ditekan
if (isset($_POST['absen']) && !$sudah_absen) {
    $status = "Hadir";
    
    // Cek keterlambatan berdasarkan batas waktu
    if ($current_time > $user['batas_waktu_absen']) {
        $status = "Terlambat";
    }
    
    $sql_absen = "INSERT INTO absensi (user_id, tanggal, waktu, status) 
                  VALUES ('$user_id', '$current_date', '$current_time', '$status')";
    
    if ($conn->query($sql_absen) === TRUE) {
        $absen_message = "Absensi berhasil dicatat!";
        $absen_status = "success";
        $sudah_absen = true;
    } else {
        $absen_message = "Gagal mencatat absensi: " . $conn->error;
        $absen_status = "error";
    }
}

// Proses pengajuan cuti jika form disubmit
if (isset($_POST['ajukan_cuti'])) {
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_selesai = $_POST['tanggal_selesai'];
    $alasan = $_POST['alasan'];
    
    $sql_cuti = "INSERT INTO pengajuan_cuti (user_id, nama, tanggal_mulai, tanggal_selesai, alasan, status) 
                VALUES ('$user_id', '{$user['nama']}', '$tanggal_mulai', '$tanggal_selesai', '$alasan', 'Menunggu')";
    
    if ($conn->query($sql_cuti) === TRUE) {
        $cuti_message = "Pengajuan cuti berhasil diajukan!";
        $cuti_status = "success";
    } else {
        $cuti_message = "Gagal mengajukan cuti: " . $conn->error;
        $cuti_status = "error";
    }
}
?>

<!-- HTML dan CSS tetap sama -->

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Pegawai - Dashboard</title>
    <style>
        :root {
            --primary: #3498db;
            --primary-dark: #2980b9;
            --secondary: #2c3e50;
            --secondary-light: #34495e;
            --success: #27ae60;
            --warning: #f39c12;
            --danger: #e74c3c;
            --light: #ecf0f1;
            --dark: #2c3e50;
            --gray: #7f8c8d;
            --white: #ffffff;
        }
        html{
            scroll-behavior: smooth;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: var(--dark);
            line-height: 1.6;
        }
        
        /* Header styles */
        .header {
            background-color: var(--primary);
            color: var(--white);
            padding: 15px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 22px;
            font-weight: bold;
            display: flex;
            align-items: center;
        }
        
        .logo-icon {
            margin-right: 10px;
            font-size: 24px;
        }
        
        .user-menu {
            display: flex;
            align-items: center;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }
        
        .user-photo {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--white);
            margin-right: 10px;
        }
        
        .user-name {
            font-weight: 500;
        }
        
        .btn-logout {
            background-color: rgba(255,255,255,0.2);
            color: var(--white);
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
        
        .btn-logout:hover {
            background-color: rgba(255,255,255,0.3);
        }
        
        .btn-icon {
            margin-right: 5px;
        }
        
        /* Sidebar and main content */
        .main-container {
            display: flex;
            margin-top: 20px;
        }
        
        .sidebar {
            width: 250px;
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            padding: 20px;
            margin-right: 20px;
            height: fit-content;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            border-radius: 4px;
            color: var(--dark);
            text-decoration: none;
            transition: background-color 0.3s;
        }
        
        .sidebar-menu a:hover {
            background-color: #f5f7fa;
        }
        
        .sidebar-menu a.active {
            background-color: var(--primary);
            color: var(--white);
        }
        
        .menu-icon {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            flex: 1;
        }
        
        /* Dashboard cards */
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .welcome-message {
            font-size: 24px;
            font-weight: 500;
        }
        
        .welcome-date {
            color: var(--gray);
            font-size: 14px;
        }
        
        .quick-actions {
            display: flex;
            gap: 10px;
        }
        
        .btn {
            padding: 10px 15px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: opacity 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            border: none;
            font-size: 14px;
        }
        
        .btn:hover {
            opacity: 0.9;
        }
        
        .btn-primary {
            background-color: var(--primary);
            color: var(--white);
        }
        
        .btn-success {
            background-color: var(--success);
            color: var(--white);
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .dashboard-card {
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 1rem;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--light);
        }
        
        .card-title {
            font-size: 18px;
            font-weight: 500;
        }
        
        .card-action {
            color: var(--primary);
            text-decoration: none;
            font-size: 14px;
        }
        
        .card-action:hover {
            text-decoration: underline;
        }
        
        /* Stats cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            padding: 20px;
            text-align: center;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-icon {
            font-size: 36px;
            margin-bottom: 10px;
        }
        
        .stat-number {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: var(--gray);
            font-size: 14px;
        }
        
        .stat-hadir .stat-icon, .stat-hadir .stat-number {
            color: var(--success);
        }
        
        .stat-izin .stat-icon, .stat-izin .stat-number {
            color: var(--primary);
        }
        
        .stat-terlambat .stat-icon, .stat-terlambat .stat-number {
            color: var(--warning);
        }
        
        /* Attendance table */
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .table th, .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--light);
        }
        
        .table th {
            background-color: #f8f9fa;
            font-weight: 500;
        }
        
        .table tr:hover {
            background-color: #f8f9fa;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-hadir {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        
        .status-izin {
            background-color: #e3f2fd;
            color: #1565c0;
        }
        
        .status-terlambat {
            background-color: #fff3e0;
            color: #e65100;
        }
        
        .status-pending {
            background-color: #f5f5f5;
            color: #616161;
        }
        
        .status-disetujui {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        
        .status-ditolak {
            background-color: #ffebee;
            color: #c62828;
        }
        
        /* Forms */
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .form-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .form-input:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }
        
        .form-textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            min-height: 100px;
            resize: vertical;
        }
        
        .form-textarea:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }
        
        /* Alerts */
        .alert {
            padding: 12px 15px;
            border-radius: 4px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* Profile card */
        .profile-card {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .profile-photo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 20px;
            border: 3px solid var(--primary);
        }
        
        .profile-details {
            flex: 1;
        }
        
        .profile-name {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .profile-position {
            color: var(--gray);
            margin-bottom: 5px;
        }
        
        .profile-department {
            display: inline-block;
            background-color: #f5f7fa;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            color: var(--gray);
        }
        
        .profile-info {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 15px;
        }
        
        .info-item {
            display: flex;
            align-items: center;
        }
        
        .info-label {
            font-weight: 500;
            margin-right: 5px;
            color: var(--gray);
        }
        
        .info-value {
            color: var(--dark);
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .main-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                margin-right: 0;
                margin-bottom: 20px;
            }
            
            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
            }
            
            .sidebar-menu li {
                margin-right: 10px;
            }
        }
        
        @media (max-width: 768px) {
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .profile-card {
                flex-direction: column;
                text-align: center;
            }
            
            .profile-photo {
                margin-right: 0;
                margin-bottom: 15px;
            }
            
            .profile-info {
                grid-template-columns: 1fr;
            }
            
            .user-info {
                display: none;
            }
        }
    </style>
</head>
<body>

<!-- Header -->
<header class="header">
    <div class="container nav-container">
        <div class="logo">
            <span class="logo-icon">👥</span>
            Portal Pegawai
        </div>
        <div class="user-menu">
            <div class="user-info">
                <img src="uploads/<?php echo !empty($user['foto']) ? $user['foto'] : 'default.jpg'; ?>" alt="Foto Profil" class="user-photo">
                <span class="user-name"><?php echo $user['nama']; ?></span>
            </div>
            <a href="user_logout.php" class="btn-logout">
                <span class="btn-icon">🚪</span> Logout
            </a>
        </div>
    </div>
</header>

<div class="container main-container">
    <!-- Sidebar -->
    <div class="sidebar">
        <ul class="sidebar-menu">
            <li><a href="user_dashboard.php" class="active"><span class="menu-icon">📊</span> Dashboard</a></li>
            <li><a href="user_profile.php"><span class="menu-icon">👤</span> Profil Saya</a></li>
            <li><a href="user_attendance.php"><span class="menu-icon">📅</span> Riwayat Absensi</a></li>
            <li><a href="user_leave.php"><span class="menu-icon">🏖️</span> Pengajuan Cuti</a></li>
            <li><a href="user_notifications.php"><span class="menu-icon">🔔</span> Notifikasi</a></li>
            <li><a href="user_settings.php"><span class="menu-icon">⚙️</span> Pengaturan</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="dashboard-header">
            <div>
                <h2 class="welcome-message">Selamat Datang, <?php echo $user['nama']; ?>!</h2>
                <p class="welcome-date"><?php echo date('l, d F Y'); ?></p>
            </div>
            <div class="quick-actions">
                <?php if (!$sudah_absen): ?>
                <form method="POST" style="display: inline;">
                    <button type="submit" name="absen" class="btn btn-success">
                        <span class="btn-icon">✓</span> Absen Sekarang
                    </button>
                </form>
                <?php else: ?>
                <button class="btn btn-success" disabled style="opacity: 0.7;">
                    <span class="btn-icon">✓</span> Sudah Absen
                </button>
                <?php endif; ?>
                <a href="#cutiForm">
                <button class="btn btn-primary" onclick="document.getElementById('cutiForm').style.display='block'">
                    <span class="btn-icon">🏖️</span>Ajukan Cuti
                </button>
                </a>
            </div>
        </div>
        
        <?php if (isset($absen_message)): ?>
        <div class="alert <?php echo $absen_status == 'success' ? 'alert-success' : 'alert-danger'; ?>">
            <?php echo $absen_message; ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($cuti_message)): ?>
        <div class="alert <?php echo $cuti_status == 'success' ? 'alert-success' : 'alert-danger'; ?>">
            <?php echo $cuti_message; ?>
        </div>
        <?php endif; ?>
        
        <!-- Profile Card -->
        <div class="dashboard-card">
            <div class="profile-card">
                <img src="uploads/<?php echo !empty($user['foto']) ? $user['foto'] : 'default.jpg'; ?>" alt="Foto Profil" class="profile-photo">
                <div class="profile-details">
                    <h3 class="profile-name"><?php echo $user['nama']; ?></h3>
                    <p class="profile-position"><?php echo $user['jabatan']; ?></p>
                    <span class="profile-department"><?php echo $user['departemen']; ?></span>
                    
                    <div class="profile-info">
                        <div class="info-item">
                            <span class="info-label">ID Pegawai:</span>
                            <span class="info-value"><?php echo $user['user_id']; ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Email:</span>
                            <span class="info-value"><?php echo $user['email']; ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Telepon:</span>
                            <span class="info-value"><?php echo $user['telepon']; ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Statistics -->
        <div class="stats-container">
            <div class="stat-card stat-hadir">
                <div class="stat-icon">✓</div>
                <div class="stat-number"><?php echo $total_hadir; ?></div>
                <div class="stat-label">Total Kehadiran</div>
            </div>
            
            <div class="stat-card stat-izin">
                <div class="stat-icon">🏖️</div>
                <div class="stat-number"><?php echo $total_izin; ?></div>
                <div class="stat-label">Total Izin/Cuti</div>
            </div>
            
            <div class="stat-card stat-terlambat">
                <div class="stat-icon">⏰</div>
                <div class="stat-number"><?php echo $total_terlambat; ?></div>
                <div class="stat-label">Total Keterlambatan</div>
            </div>
        </div>
        
        <div class="dashboard-grid">
            <!-- Recent Attendance -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h3 class="card-title">Riwayat Absensi Terbaru</h3>
                    <a href="user_attendance.php" class="card-action">Lihat Semua</a>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Waktu</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result_absensi->num_rows > 0) {
                            while ($row = $result_absensi->fetch_assoc()) {
                                $statusClass = '';
                                if ($row['status'] == 'Hadir') {
                                    $statusClass = 'status-hadir';
                                } elseif ($row['status'] == 'Izin') {
                                    $statusClass = 'status-izin';
                                } elseif ($row['status'] == 'Terlambat') {
                                    $statusClass = 'status-terlambat';
                                }
                                
                                echo "<tr>
                                        <td>" . date('d M Y', strtotime($row['tanggal'])) . "</td>
                                        <td>" . $row['waktu'] . "</td>
                                        <td><span class='status-badge {$statusClass}'>{$row['status']}</span></td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3'>Belum ada data absensi.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Leave Requests -->
            <div class="dashboard-card">
                <div class="card-header">
                    <h3 class="card-title">Pengajuan Cuti Terbaru</h3>
                    <a href="user_leave.php" class="card-action">Lihat Semua</a>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Alasan</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result_cuti->num_rows > 0) {
                            while ($row = $result_cuti->fetch_assoc()) {
                                $statusClass = '';
                                if ($row['status'] == 'Disetujui') {
                                    $statusClass = 'status-disetujui';
                                } elseif ($row['status'] == 'Ditolak') {
                                    $statusClass = 'status-ditolak';
                                } else {
                                    $statusClass = 'status-pending';
                                }
                                
                                $date_range = date('d M', strtotime($row['tanggal_mulai'])) . ' - ' . date('d M Y', strtotime($row['tanggal_selesai']));
                                
                                echo "<tr>
                                        <td>{$date_range}</td>
                                        <td>" . substr($row['alasan'], 0, 30) . (strlen($row['alasan']) > 30 ? '...' : '') . "</td>
                                        <td><span class='status-badge {$statusClass}'>{$row['status']}</span></td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3'>Belum ada pengajuan cuti.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Leave Request Form (Hidden by default) -->
        <div id="cutiForm" style="display: none;">
            <div class="dashboard-card">
                <div class="card-header">
                    <h3 class="card-title">Form Pengajuan Cuti</h3>
                    <a href="javascript:void(0)" onclick="document.getElementById('cutiForm').style.display='none'" class="card-action">Tutup</a>
                </div>
                
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label" for="tanggal_mulai">Tanggal Mulai:</label>
                        <input type="date" id="tanggal_mulai" name="tanggal_mulai" class="form-input" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="tanggal_selesai">Tanggal Selesai:</label>
                        <input type="date" id="tanggal_selesai" name="tanggal_selesai" class="form-input" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="alasan">Alasan Cuti:</label>
                        <textarea id="alasan" name="alasan" class="form-textarea" required placeholder="Jelaskan alasan pengajuan cuti Anda..."></textarea>
                    </div>
                    
                    <button type="submit" name="ajukan_cuti" class="btn btn-primary">Ajukan Cuti</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // Ensure end date is not before start date
    document.getElementById('tanggal_mulai').addEventListener('change', function() {
        document.getElementById('tanggal_selesai').min = this.value;
    });
</script>

</body>
</html>

<?php $conn->close(); ?>