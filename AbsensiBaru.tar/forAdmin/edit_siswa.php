<?php
session_start();

// Jika belum login, simpan halaman saat ini ke session dan arahkan ke login
if (!isset($_SESSION['login_user'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI']; // Simpan halaman yang ingin diakses
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

// Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses update data siswa
if (isset($_POST['update'])) {
    $user_id = $_POST['user_id'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $jurusan = $_POST['jurusan'];
    $email = $_POST['email'];
    $telepon = $_POST['telepon'];
    
    // Proses foto upload jika ada
    $foto = $_FILES['foto']['name'];
    if (!empty($foto)) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($foto);
        move_uploaded_file($_FILES['foto']['tmp_name'], $target_file);
    } else {
        // Jika tidak ada foto baru, gunakan foto yang lama
        $sql = "SELECT foto FROM users WHERE user_id='$user_id'";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $foto = $row['foto'];
    }

    // Update data siswa
    $sql_update = "UPDATE users SET nama='$nama', jabatan='$kelas', departemen='$jurusan', email='$email', telepon='$telepon', foto='$foto' WHERE user_id='$user_id'";

    if ($conn->query($sql_update) === TRUE) {
        echo "<script>alert('Data siswa berhasil diperbarui!'); window.location='daftar_siswa.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data siswa: " . $conn->error . "'); window.location='daftar_siswa.php';</script>";
    }
}

// Ambil data siswa berdasarkan user_id
if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    $sql = "SELECT * FROM users WHERE user_id='$user_id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
} else {
    header("Location: daftar_siswa.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Siswa - Sistem Manajemen Siswa</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- Header Menu -->
<header class="header">
    <div class="container nav-container">
        <div class="logo">
            <a href="dashboard.php" class="logo-link">Sistem Manajemen Siswa</a>
        </div>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="daftar_siswa.php" class="active">Daftar Siswa</a></li>
            <li><a href="data_absensi.php">Data Absensi</a></li>
            <li><a href="data_izin.php">Data Izin</a></li>
            <li><a href="tambah_siswa.php">Tambah Siswa</a></li>
        </ul>
        <div class="hamburger" id="hamburger-menu">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</header>

<!-- Mobile Navigation Menu -->
<div class="mobile-nav-overlay" id="mobile-overlay"></div>
<nav class="mobile-nav" id="mobile-nav">
    <button class="mobile-nav-close" id="mobile-nav-close">✕</button>
    
    <div class="mobile-nav-header">
        <div class="mobile-user-profile">
            <div class="mobile-user-avatar">
                <?php echo substr($_SESSION['login_user'] ?? 'A', 0, 1); ?>
            </div>
            <div class="mobile-user-info">
                <div class="mobile-user-name"><?php echo $_SESSION['login_user'] ?? 'Admin'; ?></div>
                <div class="mobile-user-role">Administrator</div>
            </div>
        </div>
    </div>
    
    <ul class="mobile-menu">
        <li>
            <a href="dashboard.php">
                <span class="mobile-menu-icon">📊</span>
                Dashboard
            </a>
        </li>
        <li>
            <a href="daftar_siswa.php" class="active">
                <span class="mobile-menu-icon">👥</span>
                Daftar Siswa
            </a>
        </li>
        <li>
            <a href="data_absensi.php">
                <span class="mobile-menu-icon">📋</span>
                Data Absensi
            </a>
        </li>
        <li>
            <a href="data_izin.php">
                <span class="mobile-menu-icon">🗓️</span>
                Data Izin
            </a>
        </li>
        <li>
            <a href="tambah_siswa.php">
                <span class="mobile-menu-icon">➕</span>
                Tambah Siswa
            </a>
        </li>
        <li>
            <a href="pengaturan.php">
                <span class="mobile-menu-icon">⚙️</span>
                Pengaturan
            </a>
        </li>
    </ul>
    
    <div class="mobile-nav-footer">
        <a href="logout.php" class="mobile-logout-btn">
            <span class="mobile-logout-icon">🚪</span>
            Logout
        </a>
    </div>
</nav>

<div class="container content"><br>
    <h2 class="page-title" style="text-align:center; margin-bottom:1rem" >Edit Data Siswa</h2>
    
    <div class="form-card">
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
            
            <div class="form-row">
                <div class="form-col">
                    <div class="form-group">
                        <label class="form-label" for="nama">Nama Lengkap:</label>
                        <input type="text" id="nama" name="nama" class="form-input" value="<?php echo $row['nama']; ?>" required>
                    </div>
                </div>
                <div class="form-col">
                    <div class="form-group">
                        <label class="form-label" for="kelas">Kelas:</label>
                        <input type="text" id="kelas" name="kelas" class="form-input" value="<?php echo $row['jabatan']; ?>" required>
                    </div>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-col">
                    <div class="form-group">
                        <label class="form-label" for="jurusan">Jurusan:</label>
                        <input type="text" id="jurusan" name="jurusan" class="form-input" value="<?php echo $row['departemen']; ?>" required>
                    </div>
                </div>
                <div class="form-col">
                    <div class="form-group">
                        <label class="form-label" for="email">Email:</label>
                        <input type="email" id="email" name="email" class="form-input" value="<?php echo $row['email']; ?>" required>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label class="form-label" for="telepon">Nomor Telepon:</label>
                <input type="text" id="telepon" name="telepon" class="form-input" value="<?php echo $row['telepon']; ?>" required>
            </div>
            
            <div class="form-group">
                <label class="form-label">Foto Siswa:</label>
                
                <div class="current-photo">
                    <img src="../uploads/<?php echo !empty($row['foto']) ? $row['foto'] : 'default.jpg'; ?>" alt="Foto Siswa Saat Ini">
                    <span class="current-photo-text">Foto saat ini</span>
                </div>
                
                <div class="file-input-wrapper">
                    <div class="file-input-button" id="fileInputButton">
                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                            <polyline points="17 8 12 3 7 8"></polyline>
                            <line x1="12" y1="3" x2="12" y2="15"></line>
                        </svg>
                        <p>Klik atau seret file foto baru ke sini</p>
                    </div>
                    <input type="file" name="foto" id="foto" class="file-input" accept="image/*">
                </div>
                <div class="file-preview">
                    <img id="imagePreview" src="#" alt="Preview Foto Baru" style="display: none;">
                </div>
                <p class="form-help-text">Biarkan kosong jika tidak ingin mengubah foto</p>
            </div>
            
            <div class="form-actions">
                <div class="form-actions-col">
                    <a href="daftar_siswa.php" class="btn-cancel">Batal</a>
                </div>
                <div class="form-actions-col">
                    <button type="submit" name="update" class="btn-submit">Simpan Perubahan</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
// Preview image before upload
document.getElementById('foto').addEventListener('change', function(e) {
    const fileInput = e.target;
    const imagePreview = document.getElementById('imagePreview');
    const fileInputButton = document.getElementById('fileInputButton');
    
    if (fileInput.files && fileInput.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            imagePreview.src = e.target.result;
            imagePreview.style.display = 'block';
            fileInputButton.style.borderColor = '#3498db';
        }
        
        reader.readAsDataURL(fileInput.files[0]);
    }
});

// Hamburger menu functionality
const hamburger = document.getElementById('hamburger-menu');
const mobileNav = document.getElementById('mobile-nav');
const mobileOverlay = document.getElementById('mobile-overlay');
const mobileMenuLinks = document.querySelectorAll('.mobile-menu a');
const mobileNavClose = document.getElementById('mobile-nav-close');

function toggleMobileMenu() {
    hamburger.classList.toggle('active');
    mobileNav.classList.toggle('active');
    mobileOverlay.classList.toggle('active');
    document.body.style.overflow = mobileNav.classList.contains('active') ? 'hidden' : '';
}

hamburger.addEventListener('click', toggleMobileMenu);
mobileOverlay.addEventListener('click', toggleMobileMenu);
mobileNavClose.addEventListener('click', toggleMobileMenu);

// Close mobile menu when a link is clicked
mobileMenuLinks.forEach(link => {
    link.addEventListener('click', toggleMobileMenu);
});
</script>

</body>
</html>

<?php $conn->close(); ?>
