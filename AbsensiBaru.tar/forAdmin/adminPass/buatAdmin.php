<?php
$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Buat password hash
$password_hashed = password_hash("admin123", PASSWORD_DEFAULT);

// Masukkan admin ke database
$sql = "INSERT INTO admin (username, password) VALUES ('admin', '$password_hashed')";

if ($conn->query($sql) === TRUE) {
    echo "Admin berhasil ditambahkan!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
