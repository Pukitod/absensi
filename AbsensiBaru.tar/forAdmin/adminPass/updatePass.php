<?php
session_start();
$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ganti dengan password baru yang diinginkan
$password_baru = "admin12345#"; // Ganti sesuai keinginan
$password_hashed = password_hash($password_baru, PASSWORD_DEFAULT);

// Update password di database
$sql = "UPDATE admin SET password='$password_hashed' WHERE username='admin'";

if ($conn->query($sql) === TRUE) {
    // Hapus sesi untuk logout
    session_destroy();
    echo "<script>
            alert('Password admin berhasil diperbarui! Silakan login kembali.');
            window.location='../login.php';
          </script>";
    exit();
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
