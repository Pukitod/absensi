<?php
session_start();

// Jika belum login, simpan halaman saat ini ke session dan arahkan ke login
if (!isset($_SESSION['login_user'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI']; // Simpan halaman yang ingin diakses
    header("Location: login.php");
    exit();
}
$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];

    // Periksa apakah file diunggah
    if (!empty($_FILES["foto"]["name"])) {
        $target_dir = "uploads/";
        $foto_name = basename($_FILES["foto"]["name"]);
        $target_file = $target_dir . $foto_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Cek apakah file adalah gambar
        $check = getimagesize($_FILES["foto"]["tmp_name"]);
        if ($check !== false) {
            if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
                // Simpan nama file ke database
                $sql = "UPDATE users SET foto='$foto_name' WHERE user_id='$user_id'";
                if ($conn->query($sql) === TRUE) {
                    echo "Foto berhasil diunggah!";
                } else {
                    echo "Error: " . $conn->error;
                }
            } else {
                echo "Gagal mengunggah foto.";
            }
        } else {
            echo "File bukan gambar!";
        }
    }
}

$conn->close();
?>

<form method="POST" enctype="multipart/form-data">
    <label>User ID:</label>
    <input type="text" name="user_id" required>
    
    <label>Foto Karyawan:</label>
    <input type="file" name="foto" required>

    <button type="submit">Upload</button>
</form>
