<?php
session_start();

// Jika belum login, simpan halaman saat ini ke session dan arahkan ke login
if (!isset($_SESSION['login_user'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI']; // Simpan halaman yang ingin diakses
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

// Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Set zona waktu
date_default_timezone_set('Asia/Singapore');

// Fungsi untuk mengirim email
function kirim_email($email, $subjek, $pesan) {
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: calvinxavianarz@gmail.com" . "\r\n"; // Ganti dengan alamat email pengirim
    mail($email, $subjek, $pesan, $headers);
}

// Proses update status cuti
if (isset($_GET['setujui_id'])) {
    $id = $_GET['setujui_id'];

    // Ambil data cuti berdasarkan ID
    $sql_cuti = "SELECT * FROM pengajuan_cuti WHERE id='$id'";
    $result_cuti = $conn->query($sql_cuti);
    $row_cuti = $result_cuti->fetch_assoc();

    $user_id = $row_cuti['user_id'];
    $tanggal_mulai = $row_cuti['tanggal_mulai'];
    $tanggal_selesai = $row_cuti['tanggal_selesai'];
    $email = $row_cuti['email'];

    // Update status cuti menjadi "Disetujui"
    $conn->query("UPDATE pengajuan_cuti SET status='Disetujui' WHERE id='$id'");

    // Pertama, hapus dulu record absensi yang sudah ada untuk rentang tanggal tersebut
    $sql_delete = "DELETE FROM absensi 
                  WHERE user_id='$user_id' 
                  AND tanggal BETWEEN '$tanggal_mulai' AND '$tanggal_selesai'";
    $conn->query($sql_delete);

    // Kemudian insert record baru dengan status Izin untuk setiap tanggal dalam rentang
    $current_date = $tanggal_mulai;
    while (strtotime($current_date) <= strtotime($tanggal_selesai)) {
        $sql_insert = "INSERT INTO absensi (user_id, tanggal, waktu, status) 
                      VALUES ('$user_id', '$current_date', '00:00:00', 'Izin')";
        $conn->query($sql_insert);
        $current_date = date('Y-m-d', strtotime($current_date . ' +1 day'));
    }

    // Kirim email notifikasi ke user
    $subjek = "Izin Anda Disetujui";
    $pesan = "Izin Anda dari tanggal {$tanggal_mulai} hingga {$tanggal_selesai} telah disetujui dan status absensi Anda telah diubah menjadi Izin.";
    kirim_email($email, $subjek, $pesan);

    echo "<script>alert('Izin disetujui dan status absensi diubah menjadi Izin!'); window.location='data_izin.php';</script>";
} elseif (isset($_GET['tolak_id'])) {
    $id = $_GET['tolak_id'];

    // Ambil data cuti berdasarkan ID
    $sql_cuti = "SELECT * FROM pengajuan_cuti WHERE id='$id'";
    $result_cuti = $conn->query($sql_cuti);
    $row_cuti = $result_cuti->fetch_assoc();

    $user_id = $row_cuti['user_id'];
    $tanggal_mulai = $row_cuti['tanggal_mulai'];
    $tanggal_selesai = $row_cuti['tanggal_selesai'];
    $email = $row_cuti['email'];

    // Update status cuti menjadi "Ditolak"
    $conn->query("UPDATE pengajuan_cuti SET status='Ditolak' WHERE id='$id'");

    // Untuk penolakan, kita hanya mengubah yang belum absen menjadi Alpa
    $current_date = $tanggal_mulai;
    while (strtotime($current_date) <= strtotime($tanggal_selesai)) {
        // Cek apakah sudah ada record absensi untuk tanggal ini
        $sql_check = "SELECT * FROM absensi WHERE user_id='$user_id' AND tanggal='$current_date'";
        $result_check = $conn->query($sql_check);
        
        if ($result_check->num_rows == 0) {
            // Jika belum ada, insert sebagai Alpa
            $sql_insert = "INSERT INTO absensi (user_id, tanggal, waktu, status) 
                          VALUES ('$user_id', '$current_date', '00:00:00', 'Alpa')";
            $conn->query($sql_insert);
        }
        $current_date = date('Y-m-d', strtotime($current_date . ' +1 day'));
    }

    // Kirim email notifikasi ke user
    $subjek = "Izin Anda Ditolak";
    $pesan = "Izin Anda dari tanggal {$tanggal_mulai} hingga {$tanggal_selesai} telah ditolak. Status absensi Anda telah diubah menjadi Alpa untuk hari-hari yang belum diisi.";
    kirim_email($email, $subjek, $pesan);

    echo "<script>alert('Izin ditolak! Status absensi diubah menjadi Alpa untuk hari-hari yang belum diisi.'); window.location='data_izin.php';</script>";
}

// Proses Clear All
if (isset($_GET['clear_all'])) {
    // Reset status absensi ke "Hadir" untuk semua yang sebelumnya "Izin" atau "Alpa"
    $conn->query("UPDATE absensi SET status='Hadir' WHERE status IN ('Izin', 'Alpa')");

    // Hapus semua data dari tabel pengajuan_cuti
    $conn->query("DELETE FROM pengajuan_cuti");

    echo "<script>alert('Semua pengajuan izin telah dihapus!'); window.location='data_izin.php';</script>";
}

// Filter tanggal
$where_clause = "";
$tanggal_awal = isset($_GET['tanggal_awal']) ? $_GET['tanggal_awal'] : '';
$tanggal_akhir = isset($_GET['tanggal_akhir']) ? $_GET['tanggal_akhir'] : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

// Bangun WHERE clause berdasarkan filter
if (!empty($tanggal_awal) && !empty($tanggal_akhir)) {
    $where_clause .= " AND (p.tanggal_mulai BETWEEN '$tanggal_awal' AND '$tanggal_akhir' 
                      OR p.tanggal_selesai BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
                      OR ('$tanggal_awal' BETWEEN p.tanggal_mulai AND p.tanggal_selesai))";
}

if (!empty($status_filter) && $status_filter != 'all') {
    $where_clause .= " AND p.status = '$status_filter'";
}

// Ambil data pengajuan cuti dengan filter
$sql = "SELECT p.*, u.foto, u.jabatan, u.departemen FROM pengajuan_cuti p 
        LEFT JOIN users u ON p.user_id = u.user_id 
        WHERE 1=1 $where_clause
        ORDER BY p.created_at DESC";
$result = $conn->query($sql);

// Hitung statistik
$sql_total = "SELECT COUNT(*) as total FROM pengajuan_cuti";
$result_total = $conn->query($sql_total);
$total_izin = $result_total->fetch_assoc()['total'] ?? 0;

$sql_pending = "SELECT COUNT(*) as total FROM pengajuan_cuti WHERE status='Menunggu'";
$result_pending = $conn->query($sql_pending);
$total_pending = $result_pending->fetch_assoc()['total'] ?? 0;

$sql_approved = "SELECT COUNT(*) as total FROM pengajuan_cuti WHERE status='Disetujui'";
$result_approved = $conn->query($sql_approved);
$total_approved = $result_approved->fetch_assoc()['total'] ?? 0;

$sql_rejected = "SELECT COUNT(*) as total FROM pengajuan_cuti WHERE status='Ditolak'";
$result_rejected = $conn->query($sql_rejected);
$total_rejected = $result_rejected->fetch_assoc()['total'] ?? 0;

// Format tanggal untuk tampilan
$tanggal_tampil = date('d') . ' ' . [
    'January' => 'Januari',
    'February' => 'Februari',
    'March' => 'Maret',
    'April' => 'April',
    'May' => 'Mei',
    'June' => 'Juni',
    'July' => 'Juli',
    'August' => 'Agustus',
    'September' => 'September',
    'October' => 'Oktober',
    'November' => 'November',
    'December' => 'Desember'
][date('F')] . ' ' . date('Y');

$hari_tampil = [
    'Sunday' => 'Minggu',
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu'
][date('l')];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengajuan Izin - Sistem Manajemen Siswa</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- Header Menu -->
<header class="header">
    <div class="container nav-container">
        <div class="logo">
            <a href="dashboard.php" class="logo-link">Sistem Manajemen Siswa</a>
        </div>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="daftar_siswa.php">Daftar Siswa</a></li>
            <li><a href="data_absensi.php">Data Absensi</a></li>
            <li><a href="data_izin.php" class="active">Data Izin</a></li>
            <li><a href="tambah_siswa.php">Tambah Siswa</a></li>
        </ul>
        <div class="hamburger" id="hamburger-menu">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</header>

<!-- Mobile Navigation Menu -->
<div class="mobile-nav-overlay" id="mobile-overlay"></div>
<nav class="mobile-nav" id="mobile-nav">
    <button class="mobile-nav-close" id="mobile-nav-close">✕</button>
    
    <div class="mobile-nav-header">
        <div class="mobile-user-profile">
            <div class="mobile-user-avatar">
                <?php echo substr($_SESSION['login_user'] ?? 'A', 0, 1); ?>
            </div>
            <div class="mobile-user-info">
                <div class="mobile-user-name"><?php echo $_SESSION['login_user'] ?? 'Admin'; ?></div>
                <div class="mobile-user-role">Administrator</div>
            </div>
        </div>
    </div>
    
    <ul class="mobile-menu">
        <li>
            <a href="dashboard.php">
                <span class="mobile-menu-icon">📊</span>
                Dashboard
            </a>
        </li>
        <li>
            <a href="daftar_siswa.php">
                <span class="mobile-menu-icon">👥</span>
                Daftar Siswa
            </a>
        </li>
        <li>
            <a href="data_absensi.php">
                <span class="mobile-menu-icon">📋</span>
                Data Absensi
            </a>
        </li>
        <li>
            <a href="data_izin.php" class="active">
                <span class="mobile-menu-icon">🗓️</span>
                Data Izin
            </a>
        </li>
        <li>
            <a href="tambah_siswa.php">
                <span class="mobile-menu-icon">➕</span>
                Tambah Siswa
            </a>
        </li>
        <li>
            <a href="pengaturan.php">
                <span class="mobile-menu-icon">⚙️</span>
                Pengaturan
            </a>
        </li>
    </ul>
    
    <div class="mobile-nav-footer">
        <a href="logout.php" class="mobile-logout-btn">
            <span class="mobile-logout-icon">🚪</span>
            Logout
        </a>
    </div>
</nav>


<div class="container content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Daftar Pengajuan Izin Siswa</h2>
            <div class="date-display"><?= "$hari_tampil, $tanggal_tampil" ?></div>
        </div>
        <div class="action-button">
            <?php if ($result->num_rows > 0): ?>
                <a href="data_izin.php?clear_all=true" class="btn btn-clear" 
                   onclick="return confirm('Yakin hapus semua pengajuan?')">
                    <span class="btn-icon">🗑️</span> Hapus Semua
                </a>
            <?php endif; ?>
            <a href="logout.php" class="btn btn-logout">
                <span class="btn-icon">🚪</span> Logout
            </a>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="filter-container">
    <form id="filterForm" method="GET" action="data_izin.php">
        <div class="filter-row">
            <div class="filter-group">
                <label class="filter-label" for="tanggal_awal">Tanggal Awal:</label>
                <input type="date" id="tanggal_awal" name="tanggal_awal" class="filter-input" 
                       value="<?= $tanggal_awal ?>">
            </div>
            
            <div class="filter-group">
                <label class="filter-label" for="tanggal_akhir">Tanggal Akhir:</label>
                <input type="date" id="tanggal_akhir" name="tanggal_akhir" class="filter-input" 
                       value="<?= $tanggal_akhir ?>">
            </div>
            
            <div class="filter-group">
                <label class="filter-label" for="status">Status:</label>
                <select id="status" name="status" class="filter-select">
                    <option value="all" <?= $status_filter == 'all' ? 'selected' : '' ?>>Semua Status</option>
                    <option value="Menunggu" <?= $status_filter == 'Menunggu' ? 'selected' : '' ?>>Menunggu</option>
                    <option value="Disetujui" <?= $status_filter == 'Disetujui' ? 'selected' : '' ?>>Disetujui</option>
                    <option value="Ditolak" <?= $status_filter == 'Ditolak' ? 'selected' : '' ?>>Ditolak</option>
                </select>
            </div>
        </div>
        
        <div class="filter-buttons-container">
            <div class="filter-actions">
                <button type="submit" class="filter-button">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    Filter Data
                </button>
                
                <a href="data_izin.php" class="filter-button filter-button-reset">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M3 2v6h6"></path>
                        <path d="M3 13a9 9 0 1 0 3-7.7L3 8"></path>
                    </svg>
                    Reset Filter
                </a>
            </div>
        </div>
    </form>
</div>

    <!-- Stats Container -->
    <div class="stats-container">
        <div class="stat-card stat-total" data-filter="all">
            <div class="stat-icon">📑</div>
            <div class="stat-number"><?= $total_izin ?></div>
            <div class="stat-label">Total Pengajuan</div>
        </div>
        
        <div class="stat-card stat-pending" data-filter="Menunggu">
            <div class="stat-icon">⏳</div>
            <div class="stat-number"><?= $total_pending ?></div>
            <div class="stat-label">Menunggu</div>
        </div>
        
        <div class="stat-card stat-approved" data-filter="Disetujui">
            <div class="stat-icon">✅</div>
            <div class="stat-number"><?= $total_approved ?></div>
            <div class="stat-label">Disetujui</div>
        </div>
        
        <div class="stat-card stat-rejected" data-filter="Ditolak">
            <div class="stat-icon">❌</div>
            <div class="stat-number"><?= $total_rejected ?></div>
            <div class="stat-label">Ditolak</div>
        </div>
    </div>

    <!-- Tabel dengan Data Status -->
    <div class="data-card">
        <table>
            <tr>
                <th>Siswa</th>
                <th>Tanggal Mulai</th>
                <th>Tanggal Selesai</th>
                <th>Alasan</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>

            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr data-status="<?= $row['status'] ?>">
                        <td>
                            <div class="student-info">
                                <img src="../uploads/<?= $row['foto'] ?? 'default.jpg' ?>" 
                                     class="student-photo" alt="Foto Siswa">
                                <div>
                                    <div class="student-name"><?= $row['nama'] ?></div>
                                    <div class="student-class">
                                        <?= $row['jabatan'] ?> - <?= $row['departemen'] ?>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td><?= $row['tanggal_mulai'] ?></td>
                        <td><?= $row['tanggal_selesai'] ?></td>
                        <td><?= $row['alasan'] ?></td>
                        <td>
                            <?php
                            $statusClass = match($row['status']) {
                                'Disetujui' => 'status-approved',
                                'Ditolak' => 'status-rejected',
                                default => 'status-pending'
                            };
                            ?>
                            <span class="status-badge <?= $statusClass ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($row['status'] === 'Menunggu'): ?>
                                <div class="action-cell">
                                    <a href="data_izin.php?setujui_id=<?= $row['id'] ?>" 
                                       class="btn-approve"
                                       onclick="return confirm('Setujui izin ini?')">
                                        ✅ Setujui
                                    </a>
                                    <a href="data_izin.php?tolak_id=<?= $row['id'] ?>" 
                                       class="btn-reject"
                                       onclick="return confirm('Tolak izin ini?')">
                                        ❌ Tolak
                                    </a>
                                </div>
                            <?php else: ?>
                                <span style="color: var(--text-light); font-style: italic;">Sudah diproses</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">
                        <div class="empty-state">
                            <div class="empty-icon">📅</div>
                            <div class="empty-text">
                                <?php if (!empty($tanggal_awal) || !empty($tanggal_akhir) || !empty($status_filter)): ?>
                                    Tidak ada data izin yang sesuai dengan filter
                                <?php else: ?>
                                    Tidak ada pengajuan izin saat ini
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Date validation
    const tanggalAwal = document.getElementById('tanggal_awal');
    const tanggalAkhir = document.getElementById('tanggal_akhir');
    
    tanggalAwal.addEventListener('change', function() {
        if (tanggalAkhir.value && this.value > tanggalAkhir.value) {
            tanggalAkhir.value = this.value;
        }
        tanggalAkhir.min = this.value;
    });
    
    // Stat card filtering
    const stats = document.querySelectorAll('.stat-card');
    const statusSelect = document.getElementById('status');
    
    stats.forEach(stat => {
        stat.addEventListener('click', () => {
            const filter = stat.dataset.filter;
            
            // Update active state
            stats.forEach(s => s.classList.remove('active'));
            stat.classList.add('active');
            
            // Update select value
            statusSelect.value = filter;
            
            // Submit form
            document.getElementById('filterForm').submit();
        });
    });
    
    // Set active stat based on current filter
    const currentStatus = '<?= $status_filter ?: "all" ?>';
    const activeStatCard = document.querySelector(`.stat-card[data-filter="${currentStatus}"]`);
    if (activeStatCard) {
        activeStatCard.classList.add('active');
    }
    
    // Hamburger menu functionality
    const hamburger = document.getElementById('hamburger-menu');
    const mobileNav = document.getElementById('mobile-nav');
    const mobileOverlay = document.getElementById('mobile-overlay');
    const mobileMenuLinks = document.querySelectorAll('.mobile-menu a');
    const mobileNavClose = document.getElementById('mobile-nav-close');

    function toggleMobileMenu() {
        hamburger.classList.toggle('active');
        mobileNav.classList.toggle('active');
        mobileOverlay.classList.toggle('active');
        document.body.style.overflow = mobileNav.classList.contains('active') ? 'hidden' : '';
    }

    hamburger.addEventListener('click', toggleMobileMenu);
    mobileOverlay.addEventListener('click', toggleMobileMenu);
    mobileNavClose.addEventListener('click', toggleMobileMenu);

    // Close mobile menu when a link is clicked
    mobileMenuLinks.forEach(link => {
        link.addEventListener('click', toggleMobileMenu);
    });
});
</script>

</body>
</html>

<?php $conn->close(); ?>
