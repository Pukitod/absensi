<?php
$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$bulan = '05';
$tahun = '2025';
$backup_table = "absensi_backup_{$tahun}_{$bulan}";

// Restore data
$sql_restore = "INSERT INTO absensi SELECT * FROM $backup_table";
if ($conn->query($sql_restore) === TRUE) {
    echo "Data berhasil dikembalikan dari $backup_table ke absensi.";
} else {
    echo "Gagal mengembalikan data: " . $conn->error;
}

$conn->close();

//kalau data kosong
/* $sql_restore = "INSERT INTO absensi SELECT * FROM absensi_backup_2025_05";
 */

//kalau ingin menghindari duplikasi
/*$sql_restore = "
    INSERT INTO absensi
    SELECT * FROM absensi_backup_2025_05
    WHERE id NOT IN (SELECT id FROM absensi)";
*/
?>