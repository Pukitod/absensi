<?php
session_start();

// Jika belum login, simpan halaman saat ini ke session dan arahkan ke login
if (!isset($_SESSION['login_user'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI']; // Simpan halaman yang ingin diakses
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

// Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses hapus siswa jika tombol hapus diklik
if (isset($_GET['hapus_id'])) {
    $hapus_id = $_GET['hapus_id'];
    $sql_hapus = "DELETE FROM users WHERE user_id = '$hapus_id'";
    
    if ($conn->query($sql_hapus) === TRUE) {
        echo "<script>alert('Siswa berhasil dihapus!'); window.location='daftar_siswa.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus siswa: " . $conn->error . "'); window.location='daftar_siswa.php';</script>";
    }
}

// Ambil data siswa dari database
$sql = "SELECT user_id, nama, jabatan, departemen, email, telepon, foto FROM users ORDER BY nama ASC";
$result = $conn->query($sql);

// Hitung total siswa
$sql_total_siswa = "SELECT COUNT(*) as total FROM users";
$result_total_siswa = $conn->query($sql_total_siswa);
$total_siswa = $result_total_siswa->fetch_assoc()['total'] ?? 0;

// Hitung jumlah siswa per kelas
$sql_kelas = "SELECT jabatan, COUNT(*) as total FROM users GROUP BY jabatan";
$result_kelas = $conn->query($sql_kelas);
$kelas_data = [];
while ($row = $result_kelas->fetch_assoc()) {
    $kelas_data[$row['jabatan']] = $row['total'];
}

// Hitung jumlah siswa per jurusan
$sql_jurusan = "SELECT departemen, COUNT(*) as total FROM users GROUP BY departemen";
$result_jurusan = $conn->query($sql_jurusan);
$jurusan_data = [];
while ($row = $result_jurusan->fetch_assoc()) {
    $jurusan_data[$row['departemen']] = $row['total'];
}

// Format tanggal untuk tampilan
$tanggal_tampil = date('d') . ' ' . [
    'January' => 'Januari',
    'February' => 'Februari',
    'March' => 'Maret',
    'April' => 'April',
    'May' => 'Mei',
    'June' => 'Juni',
    'July' => 'Juli',
    'August' => 'Agustus',
    'September' => 'September',
    'October' => 'Oktober',
    'November' => 'November',
    'December' => 'Desember'
][date('F')] . ' ' . date('Y');

$hari_tampil = [
    'Sunday' => 'Minggu',
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu'
][date('l')];

// Fungsi untuk masking data sensitif
function maskEmail($email) {
    if (empty($email)) return '-';
    $parts = explode('@', $email);
    if (count($parts) != 2) return $email;
    
    $username = $parts[0];
    $domain = $parts[1];
    
    if (strlen($username) <= 2) {
        $maskedUsername = str_repeat('*', strlen($username));
    } else {
        $maskedUsername = substr($username, 0, 2) . str_repeat('*', strlen($username) - 2);
    }
    
    return $maskedUsername . '@' . $domain;
}

function maskPhone($phone) {
    if (empty($phone)) return '-';
    $phone = preg_replace('/[^0-9]/', '', $phone); // Remove non-numeric characters
    
    if (strlen($phone) <= 4) {
        return str_repeat('*', strlen($phone));
    }
    
    $start = substr($phone, 0, 4);
    $end = substr($phone, -2);
    $middle = str_repeat('*', strlen($phone) - 6);
    
    return $start . $middle . $end;
}

function maskStudentId($id) {
    if (empty($id)) return '-';
    
    if (strlen($id) <= 4) {
        return str_repeat('*', strlen($id));
    }
    
    $start = substr($id, 0, 2);
    $end = substr($id, -2);
    $middle = str_repeat('*', strlen($id) - 4);
    
    return $start . $middle . $end;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Siswa - Sistem Manajemen Siswa</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
.sensitive-data.masked {
    color: #666;
    font-family: monospace;
    background-color: #f0f0f0;
    padding: 2px 4px;
    border-radius: 3px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.sensitive-data.masked:hover {
    background-color: #e0e0e0;
}

.sensitive-data.revealed {
    color: #333;
    background-color: #e8f5e8;
    font-weight: bold;
}

.btn-toggle {
    background-color: #17a2b8;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.btn-toggle:hover {
    background-color: #138496;
}

.privacy-warning {
    background-color: #fff3cd;
    border: 1px solid #ffeaa7;
    color: #856404;
    padding: 10px;
    border-radius: 4px;
    margin-bottom: 15px;
    display: none;
}

.privacy-warning.show {
    display: block;
}
</style>
</head>
<body>

<!-- Header Menu -->
<header class="header">
    <div class="container nav-container">
        <div class="logo">
            <a href="dashboard.php" class="logo-link">Sistem Manajemen Siswa</a>
        </div>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="daftar_siswa.php" class="active">Daftar Siswa</a></li>
            <li><a href="data_absensi.php">Data Absensi</a></li>
            <li><a href="data_izin.php">Data Izin</a></li>
            <li><a href="tambah_siswa.php">Tambah Siswa</a></li>
        </ul>
        <div class="hamburger" id="hamburger-menu">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</header>

<!-- Mobile Navigation Menu -->
<div class="mobile-nav-overlay" id="mobile-overlay"></div>
<nav class="mobile-nav" id="mobile-nav">
    <button class="mobile-nav-close" id="mobile-nav-close">✕</button>
    
    <div class="mobile-nav-header">
        <div class="mobile-user-profile">
            <div class="mobile-user-avatar">
                <?php echo substr($_SESSION['login_user'] ?? 'A', 0, 1); ?>
            </div>
            <div class="mobile-user-info">
                <div class="mobile-user-name"><?php echo $_SESSION['login_user'] ?? 'Admin'; ?></div>
                <div class="mobile-user-role">Administrator</div>
            </div>
        </div>
    </div>
    
    <ul class="mobile-menu">
        <li>
            <a href="dashboard.php">
                <span class="mobile-menu-icon">📊</span>
                Dashboard
            </a>
        </li>
        <li>
            <a href="daftar_siswa.php" class="active">
                <span class="mobile-menu-icon">👥</span>
                Daftar Siswa
            </a>
        </li>
        <li>
            <a href="data_absensi.php">
                <span class="mobile-menu-icon">📋</span>
                Data Absensi
            </a>
        </li>
        <li>
            <a href="data_izin.php">
                <span class="mobile-menu-icon">🗓️</span>
                Data Izin
            </a>
        </li>
        <li>
            <a href="tambah_siswa.php">
                <span class="mobile-menu-icon">➕</span>
                Tambah Siswa
            </a>
        </li>
        <li>
            <a href="pengaturan.php">
                <span class="mobile-menu-icon">⚙️</span>
                Pengaturan
            </a>
        </li>
    </ul>
    
    <div class="mobile-nav-footer">
        <a href="logout.php" class="mobile-logout-btn">
            <span class="mobile-logout-icon">🚪</span>
            Logout
        </a>
    </div>
</nav>

<div class="container content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Daftar Siswa</h2>
            <div class="date-display"><?php echo $hari_tampil . ', ' . $tanggal_tampil; ?></div>
        </div>
        <div class="action-button">
    <button id="toggleSensitiveData" class="btn btn-toggle" title="Toggle Data Sensitif">
        <span class="btn-icon">👁️</span> <span id="toggleText">Tampilkan Data</span>
    </button>
    <a href="tambah_siswa.php" class="btn btn-add">
        <span class="btn-icon">➕</span> Tambah Siswa
    </a>
    <a href="logout.php" class="btn btn-logout">
        <span class="btn-icon">🚪</span> Logout
    </a>
</div>
    </div>
    
    <div class="stats-container">
        <div class="stat-card stat-total" data-filter="all">
            <div class="stat-icon">👥</div>
            <div class="stat-number"><?php echo $total_siswa; ?></div>
            <div class="stat-label">Total Siswa</div>
        </div>
        
        <?php if (!empty($kelas_data)): ?>
        <div class="stat-card stat-kelas" data-filter="kelas">
            <div class="stat-icon">🏫</div>
            <div class="stat-number"><?php echo count($kelas_data); ?></div>
            <div class="stat-label">Jumlah Kelas</div>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($jurusan_data)): ?>
        <div class="stat-card stat-jurusan" data-filter="jurusan">
            <div class="stat-icon">📚</div>
            <div class="stat-number"><?php echo count($jurusan_data); ?></div>
            <div class="stat-label">Jumlah Jurusan</div>
        </div>
        <?php endif; ?>
    </div>
    
    <div class="filter-container">
        <div class="filter-form">
            <div class="filter-group">
                <label class="filter-label" for="search">Cari Siswa:</label>
                <input type="text" id="search" class="filter-input" placeholder="Masukkan nama atau NIS siswa...">
            </div>
            <div class="filter-actions">
                <button type="button" id="search-btn" class="filter-button">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg> Cari
                </button>
                <button type="button" id="reset-filter" class="filter-button filter-button-reset">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M3 2v6h6"></path>
                        <path d="M3 13a9 9 0 1 0 3-7.7L3 8"></path>
                    </svg> Reset Filter
                </button>
            </div>
        </div>
    </div>
    
    <div class="data-card">
        <div class="table-responsive">
            <table>
                <tr>
                    <th>Siswa</th>
                    <th>NIS/NISN</th>
                    <th>Kelas</th>
                    <th>Jurusan</th>
                    <th>Kontak</th>
                    <th>Aksi</th>
                </tr>

                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Pastikan foto tersedia, jika tidak gunakan default.jpg
                        $foto = !empty($row['foto']) ? $row['foto'] : '../default.jpg';

                        echo "<tr data-nama='{$row['nama']}' data-id='{$row['user_id']}' data-kelas='{$row['jabatan']}' data-jurusan='{$row['departemen']}'>
        <td>
            <div class='student-info'>
                <img src='../uploads/{$foto}' alt='Foto Siswa' class='student-photo'>
                <div>
                    <div class='student-name'>{$row['nama']}</div>
                    <div class='student-class'>{$row['jabatan']} - {$row['departemen']}</div>
                </div>
            </div>
        </td>
        <td>
            <span class='sensitive-data masked' data-original='{$row['user_id']}'>" . maskStudentId($row['user_id']) . "</span>
        </td>
        <td>{$row['jabatan']}</td>
        <td>{$row['departemen']}</td>
        <td>
            <div>Email: <span class='sensitive-data masked' data-original='{$row['email']}'>" . maskEmail($row['email']) . "</span></div>
            <div>Telepon: <span class='sensitive-data masked' data-original='{$row['telepon']}'>" . maskPhone($row['telepon']) . "</span></div>
        </td>
        <td class='action-cell'>
            <a href='edit_siswa.php?user_id={$row['user_id']}' class='btn-action'>✏ Edit</a>
            <a href='daftar_siswa.php?hapus_id={$row['user_id']}' class='btn-action btn-delete' onclick='return confirm(\"Yakin ingin menghapus siswa ini?\")'>🗑 Hapus</a>
        </td>
      </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>
                            <div class='empty-state'>
                                <div class='empty-icon'>👥</div>
                                <div class='empty-text'>Tidak ada data siswa untuk ditampilkan.</div>
                            </div>
                          </td></tr>";
                }
                ?>
            </table>
        </div>
    </div>
</div>

<script>
// Hamburger menu functionality
const hamburger = document.getElementById('hamburger-menu');
const mobileNav = document.getElementById('mobile-nav');
const mobileOverlay = document.getElementById('mobile-overlay');
const mobileMenuLinks = document.querySelectorAll('.mobile-menu a');
const mobileNavClose = document.getElementById('mobile-nav-close');

function toggleMobileMenu() {
    hamburger.classList.toggle('active');
    mobileNav.classList.toggle('active');
    mobileOverlay.classList.toggle('active');
    document.body.style.overflow = mobileNav.classList.contains('active') ? 'hidden' : '';
}

hamburger.addEventListener('click', toggleMobileMenu);
mobileOverlay.addEventListener('click', toggleMobileMenu);
mobileNavClose.addEventListener('click', toggleMobileMenu);

// Close mobile menu when a link is clicked
mobileMenuLinks.forEach(link => {
    link.addEventListener('click', toggleMobileMenu);
});

// Search and filter functionality
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search');
    const searchBtn = document.getElementById('search-btn');
    const resetFilterBtn = document.getElementById('reset-filter');
    const tableRows = document.querySelectorAll('.data-card table tr:not(:first-child)');
    const statCards = document.querySelectorAll('.stat-card');
    let currentFilter = 'all';
    
    // Function to filter table rows
    function filterTable() {
        const searchTerm = searchInput.value.toLowerCase();
        let hasVisibleRows = false;
        
        // Remove existing empty search row
        const existingEmptyRow = document.getElementById('empty-search-row');
        if (existingEmptyRow) {
            existingEmptyRow.remove();
        }
        
        tableRows.forEach(row => {
            const nama = row.getAttribute('data-nama')?.toLowerCase() || '';
            const id = row.getAttribute('data-id')?.toLowerCase() || '';
            const kelas = row.getAttribute('data-kelas')?.toLowerCase() || '';
            const jurusan = row.getAttribute('data-jurusan')?.toLowerCase() || '';
            
            let matchesSearch = searchTerm === '' || 
                               nama.includes(searchTerm) || 
                               id.includes(searchTerm) ||
                               kelas.includes(searchTerm) ||
                               jurusan.includes(searchTerm);
            
            let matchesFilter = true;
            if (currentFilter === 'kelas') {
                // Show all for now, can be enhanced to filter by specific class
                matchesFilter = true;
            } else if (currentFilter === 'jurusan') {
                // Show all for now, can be enhanced to filter by specific department
                matchesFilter = true;
            }
            
            if (matchesSearch && matchesFilter) {
                row.classList.remove('hidden-row');
                hasVisibleRows = true;
            } else {
                row.classList.add('hidden-row');
            }
        });
        
        // Show empty state if no rows match
        if (!hasVisibleRows && searchTerm !== '') {
            const table = document.querySelector('.data-card table');
            const emptyRow = document.createElement('tr');
            emptyRow.id = 'empty-search-row';
            emptyRow.innerHTML = `<td colspan="6">
                <div class="empty-state">
                    <div class="empty-icon">🔍</div>
                    <div class="empty-text">Tidak ada siswa yang sesuai dengan pencarian "${searchTerm}".</div>
                </div>
            </td>`;
            table.appendChild(emptyRow);
        }
        
        // Show/hide reset button
        updateResetButton();
    }
    
    // Function to update reset button visibility
    function updateResetButton() {
        const searchTerm = searchInput.value.trim();
        const hasActiveFilter = currentFilter !== 'all';
        
        if (searchTerm !== '' || hasActiveFilter) {
            resetFilterBtn.classList.add('visible');
        } else {
            resetFilterBtn.classList.remove('visible');
        }
    }
    
    // Function to reset all filters
    function resetAllFilters() {
        // Clear search input
        searchInput.value = '';
        
        // Reset current filter
        currentFilter = 'all';
        
        // Remove active class from all stat cards
        statCards.forEach(card => {
            card.classList.remove('active');
        });
        
        // Show all rows
        tableRows.forEach(row => {
            row.classList.remove('hidden-row');
        });
        
        // Remove empty search row if exists
        const existingEmptyRow = document.getElementById('empty-search-row');
        if (existingEmptyRow) {
            existingEmptyRow.remove();
        }
        
        // Hide reset button
        resetFilterBtn.classList.remove('visible');
    }
    
    // Search button click event
    searchBtn.addEventListener('click', filterTable);
    
    // Search input events
    searchInput.addEventListener('keyup', function(event) {
        if (event.key === 'Enter') {
            filterTable();
        }
    });
    
    // Real-time search as user types
    searchInput.addEventListener('input', function() {
        filterTable();
    });
    
    // Reset filter button click event
    resetFilterBtn.addEventListener('click', resetAllFilters);
    
    // Stat card click event
    statCards.forEach(card => {
        card.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Remove active class from all stat cards
            statCards.forEach(card => {
                card.classList.remove('active');
            });
            
            // Add active class to clicked card
            this.classList.add('active');
            
            // Update current filter
            currentFilter = filter;
            
            // Apply filter
            filterTable();
        });
    });
    
    // Initialize reset button state
    updateResetButton();
});

// Privacy toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    const toggleBtn = document.getElementById('toggleSensitiveData');
    const toggleText = document.getElementById('toggleText');
    const sensitiveElements = document.querySelectorAll('.sensitive-data');
    let isRevealed = false;
    
    // Create privacy warning
    const warningDiv = document.createElement('div');
    warningDiv.className = 'privacy-warning';
    warningDiv.innerHTML = `
        <strong>⚠️ Peringatan Privasi:</strong> 
        Data sensitif sedang ditampilkan. Pastikan tidak ada orang lain yang melihat layar Anda.
        <button onclick="this.parentElement.classList.remove('show')" style="float: right; background: none; border: none; font-size: 16px; cursor: pointer;">×</button>
    `;
    
    // Insert warning after page header
    const pageHeader = document.querySelector('.page-header');
    pageHeader.parentNode.insertBefore(warningDiv, pageHeader.nextSibling);
    
    toggleBtn.addEventListener('click', function() {
        if (!isRevealed) {
            // Show confirmation dialog
            const confirmed = confirm(
                'Anda akan menampilkan data sensitif siswa.\n\n' +
                '⚠️ PERINGATAN PRIVASI:\n' +
                '• Pastikan tidak ada orang lain yang melihat layar Anda\n' +
                '• Data ini mengandung informasi pribadi siswa\n' +
                '• Gunakan dengan bertanggung jawab\n\n' +
                'Lanjutkan menampilkan data sensitif?'
            );
            
            if (!confirmed) {
                return;
            }
            
            // Show warning
            warningDiv.classList.add('show');
            
            // Reveal data
            sensitiveElements.forEach(element => {
                const originalData = element.getAttribute('data-original');
                element.textContent = originalData;
                element.classList.remove('masked');
                element.classList.add('revealed');
            });
            
            toggleText.textContent = 'Sembunyikan Data';
            toggleBtn.querySelector('.btn-icon').textContent = '🙈';
            isRevealed = true;
            
            // Auto-hide after 30 seconds for security
            setTimeout(() => {
                if (isRevealed) {
                    toggleBtn.click();
                }
            }, 30000);
            
        } else {
            // Hide data
            sensitiveElements.forEach(element => {
                const originalData = element.getAttribute('data-original');
                let maskedData = originalData;
                
                // Apply appropriate masking based on data type
                if (originalData.includes('@')) {
                    maskedData = maskEmailJS(originalData);
                } else if (/^\d+$/.test(originalData.replace(/[^0-9]/g, ''))) {
                    if (originalData.length > 8) {
                        maskedData = maskPhoneJS(originalData);
                    } else {
                        maskedData = maskStudentIdJS(originalData);
                    }
                }
                
                element.textContent = maskedData;
                element.classList.remove('revealed');
                element.classList.add('masked');
            });
            
            toggleText.textContent = 'Tampilkan Data';
            toggleBtn.querySelector('.btn-icon').textContent = '👁️';
            warningDiv.classList.remove('show');
            isRevealed = false;
        }
    });
    
    // JavaScript masking functions
    function maskEmailJS(email) {
        if (!email || !email.includes('@')) return email;
        const parts = email.split('@');
        const username = parts[0];
        const domain = parts[1];
        
        if (username.length <= 2) {
            return '*'.repeat(username.length) + '@' + domain;
        }
        
        return username.substring(0, 2) + '*'.repeat(username.length - 2) + '@' + domain;
    }
    
    function maskPhoneJS(phone) {
        if (!phone) return phone;
        const cleanPhone = phone.replace(/[^0-9]/g, '');
        
        if (cleanPhone.length <= 4) {
            return '*'.repeat(cleanPhone.length);
        }
        
        const start = cleanPhone.substring(0, 4);
        const end = cleanPhone.substring(cleanPhone.length - 2);
        const middle = '*'.repeat(cleanPhone.length - 6);
        
        return start + middle + end;
    }
    
    function maskStudentIdJS(id) {
        if (!id) return id;
        
        if (id.length <= 4) {
            return '*'.repeat(id.length);
        }
        
        const start = id.substring(0, 2);
        const end = id.substring(id.length - 2);
        const middle = '*'.repeat(id.length - 4);
        
        return start + middle + end;
    }
});
</script>

</body>
</html>

<?php $conn->close(); ?>
