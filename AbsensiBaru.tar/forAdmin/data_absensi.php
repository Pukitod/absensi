<?php
session_start();

// Jika belum login, simpan halaman saat ini ke session dan arahkan ke login
if (!isset($_SESSION['login_user'])) {
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI']; // Simpan halaman yang ingin diakses
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "indonesia45", "absensi2");

// Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Set zona waktu
date_default_timezone_set('Asia/Singapore');

// Dapatkan waktu saat ini
$current_time = date('H:i:s');
$batas_waktu_alpa = '07:30:00';

// Set default filter tanggal (hari ini)
$tanggal_filter = isset($_GET['tanggal']) ? $_GET['tanggal'] : date('Y-m-d');

// Handle reset tanggal
if (isset($_GET['reset_tanggal'])) {
    header("Location: data_absensi.php");
    exit();
}

// Query untuk mengambil semua siswa dan status absensi mereka
$sql = "SELECT u.user_id, u.nama, u.jabatan, u.departemen, u.foto, 
           a.id, a.tanggal, a.waktu, 
           CASE 
               WHEN a.status IS NOT NULL THEN a.status
               WHEN '$current_time' > '$batas_waktu_alpa' THEN 'Alpa'
               ELSE 'Belum Absen'
           END as status
    FROM users u
    LEFT JOIN (
        SELECT * FROM absensi WHERE tanggal = '$tanggal_filter'
    ) a ON u.user_id = a.user_id
    ORDER BY a.waktu DESC, u.nama ASC";
$result = $conn->query($sql);

// Hitung statistik untuk filter
$sql_total = "SELECT COUNT(*) as total FROM absensi WHERE tanggal = '$tanggal_filter'";
$result_total = $conn->query($sql_total);
$total_absensi = $result_total->fetch_assoc()['total'];

$sql_hadir = "SELECT COUNT(*) as total FROM absensi WHERE tanggal = '$tanggal_filter' AND status = 'Hadir'";
$result_hadir = $conn->query($sql_hadir);
$total_hadir = $result_hadir->fetch_assoc()['total'];

$sql_terlambat = "SELECT COUNT(*) as total FROM absensi WHERE tanggal = '$tanggal_filter' AND status = 'Terlambat'";
$result_terlambat = $conn->query($sql_terlambat);
$total_terlambat = $result_terlambat->fetch_assoc()['total'];

$sql_izin = "SELECT COUNT(*) as total FROM absensi WHERE tanggal = '$tanggal_filter' AND status = 'Izin'";
$result_izin = $conn->query($sql_izin);
$total_izin = $result_izin->fetch_assoc()['total'];

$sql_alpa = "SELECT COUNT(*) as total FROM absensi WHERE tanggal = '$tanggal_filter' AND status = 'Alpa'";
$result_alpa = $conn->query($sql_alpa);
$total_alpa = $result_alpa->fetch_assoc()['total'] ?? 0;

// Query untuk mendapatkan data siswa yang belum absen
$sql_belum_absen = "SELECT COUNT(*) as total FROM users 
                WHERE user_id NOT IN (
                    SELECT DISTINCT user_id FROM absensi 
                    WHERE tanggal = '$tanggal_filter'
                )";
$result_belum_absen = $conn->query($sql_belum_absen);
$total_belum_absen_raw = $result_belum_absen->fetch_assoc()['total'] ?? 0;

// Jika waktu sudah lewat batas, semua yang belum absen dianggap alpa
if ($current_time > $batas_waktu_alpa) {
    $total_alpa = $total_alpa + $total_belum_absen_raw;
    $total_belum_absen = 0;
} else {
    $total_belum_absen = $total_belum_absen_raw;
}

// Total siswa
$sql_total_siswa = "SELECT COUNT(*) as total FROM users";
$result_total_siswa = $conn->query($sql_total_siswa);
$total_siswa = $result_total_siswa->fetch_assoc()['total'] ?? 0;

// Handle Clear Data
if (isset($_GET['clear_data']) && $_GET['clear_data'] == 'true') {
    // Ambil tanggal hari ini dalam format Y-m-d
    $tanggal_hari_ini = date('Y-m-d');

    // Query untuk menghapus data absensi hanya untuk hari ini
    $sql_delete = "DELETE FROM absensi WHERE DATE(tanggal) = '$tanggal_hari_ini'";

    if ($conn->query($sql_delete) === TRUE) {
        // Redirect ke halaman data_absensi.php setelah menghapus data
        header("Location: data_absensi.php");
        exit();  // Pastikan tidak ada kode yang dijalankan setelah redirect
    } else {
        echo "<script>alert('Gagal menghapus data absensi: " . $conn->error . "');</script>";
    }
}

// Handle Download Excel
if (isset($_GET['download_excel'])) {
    $tanggal_download = isset($_GET['tanggal']) ? $_GET['tanggal'] : date('Y-m-d');
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=data_absensi_' . $tanggal_download . '.csv');
    
    $output = fopen('php://output', 'w');
    
    // Header CSV
    fputcsv($output, array('Nama', 'Kelas', 'Departemen', 'Waktu Absensi', 'Status')); //ganti ke apa dah gitu
    
    // Query data untuk diunduh
    $current_time = date('H:i:s');
    $batas_waktu_alpa = '07:30:00';
    
    $sql_download = "SELECT u.nama, u.jabatan, u.departemen, 
                        a.waktu, 
                        CASE 
                            WHEN a.status IS NOT NULL THEN a.status
                            WHEN '$current_time' > '$batas_waktu_alpa' THEN 'Alpa'
                            ELSE 'Belum Absen'
                        END as status
                    FROM users u
                    LEFT JOIN (
                        SELECT * FROM absensi WHERE tanggal = '$tanggal_download'
                    ) a ON u.user_id = a.user_id
                    ORDER BY a.waktu DESC, u.nama ASC";
    
    $result_download = $conn->query($sql_download);
    
    if ($result_download->num_rows > 0) {
        while ($row = $result_download->fetch_assoc()) {
            $waktu = $row['waktu'] ? $row['waktu'] : '-';
            fputcsv($output, array(
                $row['nama'],
                $row['jabatan'],
                $row['departemen'],
                $waktu,
                $row['status']
            ));
        }
    }
    
    fclose($output);
    exit();
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Absensi - Sistem Manajemen Siswa</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<!-- Header Menu -->
<header class="header">
    <div class="container nav-container">
        <div class="logo">
            <a href="dashboard.php" class="logo-link">Sistem Manajemen Siswa</a>
        </div>
        <ul class="nav-menu">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="daftar_siswa.php">Daftar Siswa</a></li>
            <li><a href="data_absensi.php" class="active">Data Absensi</a></li>
            <li><a href="data_izin.php">Data Izin</a></li>
            <li><a href="tambah_siswa.php">Tambah Siswa</a></li>
        </ul>
        <div class="hamburger" id="hamburger-menu">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</header>

<!-- Mobile Navigation Menu -->
<div class="mobile-nav-overlay" id="mobile-overlay"></div>
<nav class="mobile-nav" id="mobile-nav">
    <button class="mobile-nav-close" id="mobile-nav-close">✕</button>
    
    <div class="mobile-nav-header">
        <div class="mobile-user-profile">
            <div class="mobile-user-avatar">
                <?php echo substr($_SESSION['login_user'] ?? 'A', 0, 1); ?>
            </div>
            <div class="mobile-user-info">
                <div class="mobile-user-name"><?php echo $_SESSION['login_user'] ?? 'Admin'; ?></div>
                <div class="mobile-user-role">Administrator</div>
            </div>
        </div>
    </div>
    
    <ul class="mobile-menu">
        <li>
            <a href="dashboard.php">
                <span class="mobile-menu-icon">📊</span>
                Dashboard
            </a>
        </li>
        <li>
            <a href="daftar_siswa.php">
                <span class="mobile-menu-icon">👥</span>
                Daftar Siswa
            </a>
        </li>
        <li>
            <a href="data_absensi.php" class="active">
                <span class="mobile-menu-icon">📋</span>
                Data Absensi
            </a>
        </li>
        <li>
            <a href="data_izin.php">
                <span class="mobile-menu-icon">🗓️</span>
                Data Izin
            </a>
        </li>
        <li>
            <a href="tambah_siswa.php">
                <span class="mobile-menu-icon">➕</span>
                Tambah Siswa
            </a>
        </li>
        <li>
            <a href="pengaturan.php">
                <span class="mobile-menu-icon">⚙️</span>
                Pengaturan
            </a>
        </li>
    </ul>
    
    <div class="mobile-nav-footer">
        <a href="logout.php" class="mobile-logout-btn">
            <span class="mobile-logout-icon">🚪</span>
            Logout
        </a>
    </div>
</nav>

<div class="container content">
    <div class="page-header">
        <div>
            <h2 class="page-title">Data Absensi Siswa</h2>
            <?php
$tanggal_tampil = date('d') . ' ' . [
    'January' => 'Januari',
    'February' => 'Februari',
    'March' => 'Maret',
    'April' => 'April',
    'May' => 'Mei',
    'June' => 'Juni',
    'July' => 'Juli',
    'August' => 'Agustus',
    'September' => 'September',
    'October' => 'Oktober',
    'November' => 'November',
    'December' => 'Desember'
][date('F')] . ' ' . date('Y');

$hari_tampil = [
    'Sunday' => 'Minggu',
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu'
][date('l')];
?>
<div class="date-display"><?php echo $hari_tampil . ', ' . $tanggal_tampil; ?></div>
        </div>
        <div class="action-button">
            <a href="data_absensi.php?clear_data=true" class="btn btn-clear" onclick="return confirm('Yakin ingin menghapus semua data absensi?')">
                <span class="btn-icon">🗑️</span> Hapus Data Hari Ini
            </a>
            <a href="data_absensi.php?download_excel=1&tanggal=<?php echo $tanggal_filter; ?>" class="btn btn-download">
                <span class="btn-icon">📊</span> Download Excel
            </a>
            <a href="logout.php" class="btn btn-logout">
                <span class="btn-icon">🚪</span> Logout
            </a>
        </div>
    </div>
    
    <div class="filter-container">
        <form method="GET" class="filter-form">
            <div class="filter-group">
                <label class="filter-label" for="tanggal">Filter Tanggal:</label>
                <input type="date" id="tanggal" name="tanggal" class="filter-input" value="<?php echo $tanggal_filter; ?>">
            </div>
            <div class="filter-actions">
                <button type="submit" class="filter-button">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg> Tampilkan
                </button>
                <a href="data_absensi.php?reset_tanggal=true" class="filter-button filter-button-reset">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M3 2v6h6"></path>
                        <path d="M3 13a9 9 0 1 0 3-7.7L3 8"></path>
                    </svg> Reset Filter
                </a>
            </div>
        </form>

    </div>

    <div class="stats-container">
        <div class="stat-card stat-total" data-filter="all">
            <div class="stat-icon">👥</div>
            <div class="stat-number"><?php echo $total_siswa; ?></div>
            <div class="stat-label">Total Siswa</div>
        </div>
        
        <div class="stat-card stat-hadir" data-filter="Hadir">
            <div class="stat-icon">✅</div>
            <div class="stat-number"><?php echo $total_hadir; ?></div>
            <div class="stat-label">Hadir</div>
        </div>
        
        <div class="stat-card stat-terlambat" data-filter="Terlambat">
            <div class="stat-icon">⏰</div>
            <div class="stat-number"><?php echo $total_terlambat; ?></div>
            <div class="stat-label">Terlambat</div>
        </div>
        
        <div class="stat-card stat-izin" data-filter="Izin">
            <div class="stat-icon">📝</div>
            <div class="stat-number"><?php echo $total_izin; ?></div>
            <div class="stat-label">Izin</div>
        </div>
        
        <div class="stat-card stat-alpa" data-filter="Alpa">
            <div class="stat-icon">❌</div>
            <div class="stat-number"><?php echo $total_alpa; ?></div>
            <div class="stat-label">Alpa</div>
        </div>
    </div>
    
    <div class="data-card">
        <div class="table-responsive">
            <table>
                <tr>
                    <th>Siswa</th>
                    <th>Waktu</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
                
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $status = $row['status'] ?? 'Belum Absen';
                        $waktu = $row['waktu'] ?? '-';
                        
                        $status_class = '';
                        if ($status == 'Hadir') {
                            $status_class = 'status-hadir';
                        } elseif ($status == 'Terlambat') {
                            $status_class = 'status-terlambat';
                        } elseif ($status == 'Izin') {
                            $status_class = 'status-izin';
                        } elseif ($status == 'Alpa') {
                            $status_class = 'status-alpa';
                        } else {
                            $status_class = 'status-belum';
                        }
                        
                        $foto = !empty($row['foto']) ? $row['foto'] : '../default.jpg';
                        
                        echo "<tr data-status='$status'>
                                <td>
                                    <div class='student-info'>
                                        <img src='../uploads/{$foto}' alt='Foto Siswa' class='student-photo'>
                                        <div>
                                            <div class='student-name'>{$row['nama']}</div>
                                            <div class='student-class'>{$row['jabatan']} - {$row['departemen']}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>{$waktu}</td>
                                <td><span class='status-badge {$status_class}'>{$status}</span></td>
                                <td class='action-cell'>";
                      
                        if ($status == 'Belum Absen') {
                            echo "<a href='../forUser/absensi.php?user_id={$row['user_id']}' class='btn-absen'>Absen</a>";
                        } elseif ($status == 'Alpa' && !$row['id']) {
                            // Jika statusnya Alpa karena belum absen (bukan dari database)
                            echo "<a href='../forUser/absensi.php?user_id={$row['user_id']}' class='btn-absen'>Absen</a>";
                        } elseif ($row['id']) {
                            echo "<a href='edit_siswa.php?id={$row['id']}' class='btn-action'>Edit</a>
                                <a href='hapus_absensi.php?id={$row['id']}' class='btn-action btn-delete' onclick='return confirm(\"Yakin ingin menghapus data absensi ini?\")'>Hapus</a>";
                        }

                        echo "</td></tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>
                            <div class='empty-state'>
                                <div class='empty-icon'>📋</div>
                                <div class='empty-text'>Tidak ada data siswa untuk ditampilkan.</div>
                            </div>
                          </td></tr>";
                }
                ?>
            </table>
        </div>
    </div>
</div>

<script>
// Hamburger menu functionality
const hamburger = document.getElementById('hamburger-menu');
const mobileNav = document.getElementById('mobile-nav');
const mobileOverlay = document.getElementById('mobile-overlay');
const mobileMenuLinks = document.querySelectorAll('.mobile-menu a');
const mobileNavClose = document.getElementById('mobile-nav-close');

function toggleMobileMenu() {
    hamburger.classList.toggle('active');
    mobileNav.classList.toggle('active');
    mobileOverlay.classList.toggle('active');
    document.body.style.overflow = mobileNav.classList.contains('active') ? 'hidden' : '';
}

hamburger.addEventListener('click', toggleMobileMenu);
mobileOverlay.addEventListener('click', toggleMobileMenu);
mobileNavClose.addEventListener('click', toggleMobileMenu);

mobileMenuLinks.forEach(link => {
    link.addEventListener('click', toggleMobileMenu);
});

// Status filter functionality
document.addEventListener('DOMContentLoaded', function() {
    const statCards = document.querySelectorAll('.stat-card');
    const tableRows = document.querySelectorAll('.data-card table tr:not(:first-child)');
    
    function applyFilter(status) {
        // Reset semua card dan baris
        statCards.forEach(card => card.classList.remove('active'));
        tableRows.forEach(row => row.style.display = '');
        
        // Aktifkan card yang dipilih
        this.classList.add('active');
        
        // Filter baris tabel
        if (status !== 'all') {
            tableRows.forEach(row => {
                const rowStatus = row.getAttribute('data-status');
                row.style.display = rowStatus === status ? '' : 'none';
            });
        }
    }
    
    statCards.forEach(card => {
        card.addEventListener('click', function() {
            const status = this.getAttribute('data-filter');
            applyFilter.call(this, status);
        });
    });
});

// Auto refresh setiap 1 menit
setTimeout(function() {
    location.reload(); // Refresh halaman
}, 60000); // 60000 ms = 1 menit
</script>

</body>
</html>

<?php $conn->close(); ?>
