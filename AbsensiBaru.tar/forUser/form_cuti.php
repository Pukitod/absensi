<?php
$conn = new mysqli("127.0.0.1", "root", "indonesia45", "absensi2");

// Cek koneksi database
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Proses pengajuan cuti
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $tanggal_mulai = $_POST['tanggal_mulai'];
    $tanggal_selesai = $_POST['tanggal_selesai'];
    $alasan = $_POST['alasan'];

    // Cek apakah user_id ada di tabel users
    $sql = "SELECT * FROM users WHERE user_id = '$user_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nama = $row['nama'];

        // Simpan pengajuan cuti ke database
        $sql_insert = "INSERT INTO pengajuan_cuti (user_id, nama, tanggal_mulai, tanggal_selesai, alasan) 
                       VALUES ('$user_id', '$nama', '$tanggal_mulai', '$tanggal_selesai', '$alasan')";

        if ($conn->query($sql_insert) === TRUE) {
            echo "<script>alert('Pengajuan cuti berhasil dikirim!'); window.location='form_cuti.php';</script>";
        } else {
            echo "<p style='color: red;'>Gagal mengajukan cuti: " . $conn->error . "</p>";
        }
    } else {
        echo "<p style='color: red;'>User ID tidak ditemukan!</p>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pengajuan Izin/Sakit</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .form-container {
            width: 100%;
            max-width: 500px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            overflow: hidden;
            position: relative;
        }
        
        .form-header {
            background: linear-gradient(135deg, #2c3e50, #3498db);
            color: white;
            padding: 20px;
            text-align: center;
            position: relative;
        }
        
        .form-header::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 10px solid transparent;
            border-right: 10px solid transparent;
            border-top: 10px solid #3498db;
        }
        
        .form-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .form-subtitle {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .clock-display {
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            padding: 10px;
            margin-top: 15px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        
        .clock-time {
            font-size: 28px;
            font-weight: bold;
            font-family: 'Courier New', monospace;
        }
        
        .clock-date {
            font-size: 14px;
            margin-top: 5px;
        }
        
        .form-body {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #2c3e50;
            font-size: 14px;
        }
        
        .form-input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .form-input:focus {
            border-color: #3498db;
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
            outline: none;
        }
        
        .form-textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            min-height: 100px;
            resize: vertical;
            transition: all 0.3s;
        }
        
        .form-textarea:focus {
            border-color: #3498db;
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
            outline: none;
        }
        
        .btn-submit {
            width: 100%;
            background-color: #3498db;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-submit:hover {
            background-color: #2980b9;
        }
        
        .form-note {
            margin-top: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border-radius: 5px;
            font-size: 14px;
            color: #7f8c8d;
            border-left: 3px solid #3498db;
        }
        
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 3px solid #dc3545;
        }
        
        @media (max-width: 768px) {
            .form-container {
                max-width: 100%;
            }
            
            .form-header {
                padding: 15px;
            }
            
            .form-title {
                font-size: 20px;
            }
            
            .clock-time {
                font-size: 24px;
            }
            
            .form-body {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<div class="form-container">
    <div class="form-header">
        <h1 class="form-title">Form Pengajuan Izin/Sakit</h1>
        <p class="form-subtitle">Silakan isi form berikut untuk mengajukan izin atau sakit</p>
        
        <div class="clock-display">
            <div class="clock-time" id="current-time">00:00:00</div>
            <div class="clock-date" id="current-date">Senin, 1 Januari 2023</div>
        </div>
    </div>
    
    <div class="form-body">
        <form method="POST" id="izinForm">
            <div class="form-group">
                <label class="form-label" for="user_id">ID Siswa:</label>
                <input type="text" id="user_id" name="user_id" class="form-input" required placeholder="Masukkan ID siswa Anda">
            </div>
            
            <div class="form-group">
                <label class="form-label" for="tanggal_mulai">Tanggal Mulai:</label>
                <input type="date" id="tanggal_mulai" name="tanggal_mulai" class="form-input" required>
            </div>
            
            <div class="form-group">
                <label class="form-label" for="tanggal_selesai">Tanggal Selesai:</label>
                <input type="date" id="tanggal_selesai" name="tanggal_selesai" class="form-input" required>
            </div>
            
            <div class="form-group">
                <label class="form-label" for="alasan">Alasan Izin/Sakit:</label>
                <textarea id="alasan" name="alasan" class="form-textarea" required placeholder="Jelaskan alasan izin atau sakit Anda secara detail"></textarea>
            </div>
            
            <button type="submit" class="btn-submit">Kirim Pengajuan</button>
        </form>
        
        <div class="form-note">
            <p><strong>Catatan:</strong> Pengajuan izin harus dilakukan minimal 1 hari sebelum tanggal izin. Untuk sakit, harap melampirkan surat keterangan dokter saat kembali ke sekolah.</p>
        </div>
    </div>
</div>

<script>
// Update time and date
function updateDateTime() {
    const now = new Date();
    
    // Format time: HH:MM:SS
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const timeString = `${hours}:${minutes}:${seconds}`;
    
    // Format date: Day, DD Month YYYY
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const dateString = now.toLocaleDateString('id-ID', options);
    
    document.getElementById('current-time').innerText = timeString;
    document.getElementById('current-date').innerText = dateString;
}

// Update time every second
setInterval(updateDateTime, 1000);
updateDateTime();

// Form validation
document.getElementById('izinForm').addEventListener('submit', function(e) {
    const tanggalMulai = new Date(document.getElementById('tanggal_mulai').value);
    const tanggalSelesai = new Date(document.getElementById('tanggal_selesai').value);
    
    if (tanggalSelesai < tanggalMulai) {
        e.preventDefault();
        alert('Tanggal selesai tidak boleh lebih awal dari tanggal mulai!');
    }
});

// Set minimum date for date inputs to today
const today = new Date().toISOString().split('T')[0];
document.getElementById('tanggal_mulai').setAttribute('min', today);
document.getElementById('tanggal_selesai').setAttribute('min', today);

// Update tanggal_selesai min value when tanggal_mulai changes
document.getElementById('tanggal_mulai').addEventListener('change', function() {
    document.getElementById('tanggal_selesai').setAttribute('min', this.value);
});
</script>

</body>
</html>
